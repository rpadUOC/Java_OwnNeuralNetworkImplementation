package neuronalNetwork;

import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Main {

	/**
	 * @param args
	 */
	
	public void trainingSet_occupancy(){
		int numAtt = 5;
		NN n = new NN(numAtt);
		NN bestNN = null;
		boolean print = false;
		int numTotal=3458;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[numAtt];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\occupancy_mod.txt"))) {
			for(String line; (line = br.readLine()) != null; ) {
				//if(num == 2000) break;
		    	String[] parts = line.split(",");
		    	//System.out.println("parts "+line);
		    	for(int i=0; i<numAtt; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		if(print) System.out.println("parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[numAtt]);
		    	if(print) System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, numAtt);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		//entrenem
		for(int i=0;i<100;i++){
			//n.learningRate -= n.learningRate/600.0f;
			n.learningRate = 0.003f;
			n.momentum = 0.5f;
			if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			
			for(int j=0;j<(int)(numTotal*0.666f);j++){
				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	public void trainingSetRicochette_occupancy(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+", "+ricochetteSlopeThreshold+".....");
		int numAtt = 5;
		NN n = new NN(numAtt);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal=3458;
		
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[numAtt];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\occupancy_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<numAtt; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}

		    	supervised[num] = Integer.parseInt(parts[numAtt]);
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, numAtt);
		    
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<100;i++){
			n.learningRate = 0.003f;
			n.momentum = 0.5f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					holeFound = true;
					//i = 0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	
	public void trainingSet_chess(){
		int numAtt = 36;
		NN n = new NN(numAtt);
		NN bestNN = null;
		boolean print = false;
		int numTotal=3054;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[numAtt];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\chess_mod.txt"))) {
			for(String line; (line = br.readLine()) != null; ) {
				//if(num == 2000) break;
		    	String[] parts = line.split(",");
		    	//System.out.println("parts "+line);
		    	for(int i=0; i<numAtt; i++){
		    		
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		if(print) System.out.println("parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[numAtt]);
		    	if(print) System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, numAtt);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		//entrenem
		for(int i=0;i<1500;i++){
			//n.learningRate -= n.learningRate/600.0f;
			n.learningRate = 0.1f;
			n.momentum = 0.5f;
			if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			
			for(int j=0;j<(int)(numTotal*0.666f);j++){
				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	public void trainingSetRicochette_chess(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+", "+ricochetteSlopeThreshold+".....");
		int numAtt = 36;
		NN n = new NN(numAtt);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal=3054;
		
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[numAtt];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\chess_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<numAtt; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}

		    	supervised[num] = Integer.parseInt(parts[36]);
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, numAtt);
		    
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<1500;i++){
			n.learningRate = 0.1f;
			n.momentum = 0.5f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//n.learningRate = 0.1f;
					holeFound = true;
					//i = 0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				//n.learningRate = 0.1f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	
	
	
	
	public void trainingSetRicochette2(float ricochetteThreshold, float ricochetteSlopeThreshold){
		NN n = new NN(19);
		NN bestNN = null;
		boolean print = false;
		System.out.println(ricochetteThreshold+", "+ricochetteSlopeThreshold+".....");
		float mult = 0.98f;
		
		float input[][] = new float[1151][];
		for(int i=0;i<1151;i++)
			input[i] = new float[19];
		int supervised[] = new int[1151];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\messidor_features.arff"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<19; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		if(print) System.out.println("parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[19]);
		    	if(print) System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		int virgin = -99999;
		boolean holeFound = false;
		float prevQuality=100, currQuality=virgin;
		for(int i=0;i<6000;i++){
			//if(i%10 == 0) ricochetteThreshold--;
			for(int j=0;j<951;j++){
				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			currQuality = n.calculateNNQuality();
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					n.learningRate = 0.01f;
					holeFound = true;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				n.learningRate = 0.02f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQuality();
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		
		int cor=0;
		int inc=0;
		for(int i=951;i<1151;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Prediction accuracy "+100.0f*cor/(cor+inc)+" quality:"+bestNN.quality);
	}
	
	
	public void trainingSetRicochette(float ricochetteThreshold, float ricochetteSlopeThreshold){
		NN n = new NN(19);
		//n.minUp = minUpd;
		NN bestNN = null;
		boolean print = false;
		System.out.print(ricochetteThreshold+", "+ricochetteSlopeThreshold+"..... ");
		float mult = 0.98f;
		int numTotal=1080;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[19];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\messidor_features_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<19; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		if(print) System.out.println("parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[19]);
		    	if(print) System.out.println("supervised "+supervised[num]);
		    	num++;
		    	
		    }
		    input = normalitza(input, numTotal, 19);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		int virgin = -99999;
		boolean holeFound = false;
		float prevQuality=100, currQuality=virgin;
		for(int i=0;i<1000;i++){
			//if(i%10 == 0) ricochetteThreshold--;
			for(int j=0;j<(int)(numTotal*0.666f);j++){
				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			n.learningRate = 0.02f;
			n.momentum = 0.4f;
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//i = 0;
					holeFound = true;
				}
				ricochetteSlopeThreshold = ricochetteThreshold = -99999;
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	public void trainingSet(){
		NN n = new NN(19);
		NN bestNN = null;
		boolean print = false;
		int numTotal=1080;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[19];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\messidor_features_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<19; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		if(print) System.out.println("parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[19]);
		    	if(print) System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 19);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		//entrenem
		for(int i=0;i<1000;i++){
			//n.learningRate -= n.learningRate/600.0f;
			n.learningRate = 0.02f;
			n.momentum = 0.4f;
			if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			
			for(int j=0;j<(int)(numTotal*0.666f);j++){
				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	public void trainingSet_wine(){
		NN n = new NN(11);
		NN bestNN = null;
		int numTotal = 1402;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[11];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\winequality_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(";");
		    	for(int i=0; i<11; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	if(Integer.parseInt(parts[11]) > 5) supervised[num] = 1;
		    	else supervised[num] = 0;
		    	 
		    	//System.out.println("supervised "+supervised[num]);
		    	
		    	num++;
		    }
		    input = normalitza(input, numTotal, 11);
		  
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<numTotal;i++){
			n.learningRate = 0.02f ;
			n.momentum = 0.8f;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			
			//System.out.println(i+" Total error "+n.calculateTotalError(2));
			//n.showNumberOfCorrectPredictions();
			//System.out.print(i+" Total error "+n.calculateTotalError(951)+" ");
			//n.showNumberOfCorrectPredictions();
			
			float quality = n.calculateNNQuality();
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		
		int cor=0;
		int inc=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = n.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	}
	
	
	
	public void trainingSetRicochette_wine(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+", "+ricochetteSlopeThreshold+".....");
		NN n = new NN(11);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal=1402;
		
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[11];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\winequality_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(";");
		    	for(int i=0; i<11; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	if(Integer.parseInt(parts[11]) > 5) supervised[num] =1;
		    	else supervised[num] = 0;
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 11);
		    
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<(int)(numTotal*0.666f);i++){
			n.learningRate = 0.01f;
			n.momentum = 0.8f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQuality();
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					n.learningRate = 0.01f;
					holeFound = true;
					//i = 0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				n.learningRate = 0.01f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQuality();
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		
		int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	}
	
	
	/////////////////////////////////////////////
	
	public void trainingSet_banknote(){
		NN n = new NN(4);
		NN bestNN = null;
		int numTotal = 1220;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[4];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\banknote_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<4; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[4]);
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 3);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<1000;i++){
			n.learningRate = 0.02f;
			n.momentum = 0.8f;

			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	public void trainingSetRicochette_banknote(float ricochetteThreshold, float ricochetteSlopeThreshold){
			
		NN n = new NN(4);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal=1220;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[4];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\banknote_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<4; i++){
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[4]);
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 3);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<1000;i++){
			n.learningRate = 0.02f;
			n.momentum = 0.8f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//n.learningRate = 0.02f;
					holeFound = true;
					//i=0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				//n.learningRate = 0.02f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			//if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			//if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if(supervised[i]==1) nTrue++; 
			//System.out.println(pred+" - "+supervised[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	///////////////////////////////////////////////
	
	
	
	public void trainingSet_breastcancer(){
		NN n = new NN(10);
		NN bestNN = null;
		int numTotal = 482;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[10];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\breastcancer_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=1; i<10; i++){
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		input[num][i-1] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[10]);
		    	if(supervised[num] > 2) supervised[num] = 1;
		    	else supervised[num] = 0;
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 10);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<3000;i++){
			n.learningRate = 0.03f ;
			n.momentum = 0.5f;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
				//System.out.println(n.calculateNNQuality());
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue = 0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			//System.out.println(pred+" "+supervised[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	
	}
	
	
	public void trainingSetRicochette_breastcancer(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+"- "+ricochetteSlopeThreshold+" ");
		NN n = new NN(10);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal = 482;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[10];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\breastcancer_mod.txt"))) {
			for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=1; i<10; i++){
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		input[num][i-1] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[10]);
		    	if(supervised[num] > 2) supervised[num] = 1;
		    	else supervised[num] = 0;
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
			input = normalitza(input, numTotal, 10);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<3000;i++){
			n.learningRate = 0.03f ;
			n.momentum = 0.5f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//n.learningRate = 0.03f;
					holeFound = true;
					//i=0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				//n.learningRate = 0.03f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	public void trainingSet_haberman(){
		NN n = new NN(3);
		NN bestNN = null;
		int numTotal = 162;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[3];
		int supervised[] = new int[numTotal];
		int restat = 0;
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\haberman_mod.txt"))) {
		   int trues=0;
			for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<3; i++){
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[3]) - 1;
		    	if(supervised[num] == 1) trues++;
		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
			input = normalitza(input, numTotal, 3);
		
		    
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<5000;i++){
			n.learningRate = 0.4f ;
			n.momentum = 0.5f;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
				//System.out.println(n.calculateNNQuality());
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		
		
		/*int cor=0;
		int inc=0;
		int nTrue = 0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			//System.out.println(pred+" "+supervised[i]);
			if(supervised[i]==0) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	public void trainingSetRicochette_haberman(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+"- "+ricochetteSlopeThreshold+" ");
		NN n = new NN(3);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		float input[][] = new float[306][];
		for(int i=0;i<306;i++)
			input[i] = new float[3];
		int supervised[] = new int[306];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\haberman_mod.txt"))) {
			for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	for(int i=0; i<3; i++){
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		input[num][i] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[3]) - 1;

		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		   
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<5000;i++){
			n.learningRate = 0.4f ;
			n.momentum = 0.5f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<200;j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, 200, 306);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//n.learningRate = 0.02f;
					holeFound = true;
					//i=0;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				//n.learningRate = 0.02f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, 200, 306);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		for(int i=200;i<306;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Prediction accuracy "+100.0f*cor/(cor+inc)+" quality:"+bestNN.quality+" average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2));
	*/
	}
	
	
	
	
	
	public void trainingSet_randomdata(){
		NN n = new NN(3);
		NN bestNN = null;
		int numTotal = 272;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[3];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\randomdata_mod.txt"))) {
		    for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split("|");
		    	for(int i=0; i<6; i++){
		    		if(parts[i].equals("|")) continue;
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		//System.out.println(parts[i]);
		    		input[num][i/2] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[6]);

		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
		    input = normalitza(input, numTotal, 3);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<1000;i++){
			n.learningRate = 0.01f ;
			n.momentum = 0.5f;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
				//System.out.println(n.calculateNNQuality());
			}
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			/*System.out.println(i+" Total error "+n.calculateTotalError((int)(numTotal*0.666f))+" ");
			n.showNumberOfCorrectPredictions();
			int cor=0;
			int inc=0;
			for(int ii=(int)(numTotal*0.666f);ii<numTotal;ii++){
				boolean pred = bestNN.predict(input[ii]);
				if((pred && supervised[ii]==1) || (!pred && supervised[ii]==0)) cor++;
				else inc++;
			}
			System.out.println("Test set -> Correct:"+cor+" Incorrect:"+inc+"   "+ (int)(100.0f*cor/(cor+inc))+"%\n");
			*/
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		int nTrue = 0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			//System.out.println(pred+" "+supervised[i]);
			if(supervised[i]==1) nTrue++;
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	
	
	
	public void trainingSetRicochette_randomdata(float ricochetteThreshold, float ricochetteSlopeThreshold){
		System.out.print(ricochetteThreshold+"- "+ricochetteSlopeThreshold+" ");
		NN n = new NN(3);
		NN bestNN = null;
		boolean print = false;
		float mult = 0.98f;
		int numTotal = 272;
		float input[][] = new float[numTotal][];
		for(int i=0;i<numTotal;i++)
			input[i] = new float[3];
		int supervised[] = new int[numTotal];
		
		int num = 0;
		//carreguem dades
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\modificades\\randomdata_mod.txt"))) {
			for(String line; (line = br.readLine()) != null; ) {
				String[] parts = line.split("|");
		    	for(int i=0; i<6; i++){
		    		if(parts[i].equals("|")) continue;
		    		if(parts[i].equals("?")) parts[i] = "0";
		    		//System.out.println(parts[i]);
		    		input[num][i/2] = Float.parseFloat(parts[i]);
		    		//System.out.println(num + " parts "+input[num][i]);
		    	}
		    	
		    	supervised[num] = Integer.parseInt(parts[6]);

		    	//System.out.println("supervised "+supervised[num]);
		    	num++;
		    }
			input = normalitza(input, numTotal, 3);
		    //System.out.println("num 1:"+(num-zero)+"     num 0:"+zero);
		    // line is not visible here.
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//entrenem
		for(int i=0;i<1000;i++){
			n.learningRate = 0.01f;
			n.momentum = 0.5f;
			int virgin = -99999;
			boolean holeFound = false;
			float prevQuality=100, currQuality=virgin;
			//n.momentum = 0.2f + i/2000.0f;
			//System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			for(int j=0;j<(int)(numTotal*0.666f);j++){

				n.addSupervisedInput(input[j], supervised[j], false);
				n.calculateWeightGradients(supervised[j]);
				n.updateWeights(supervised[j], false);
			}
	
			currQuality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			//(currQuality*mult-prevQuality)*
			if(holeFound || (prevQuality != virgin && ricochetteSlopeThreshold>=0 && currQuality-prevQuality>ricochetteSlopeThreshold && currQuality > ricochetteThreshold)){
				if(print) System.out.println("ricochette has found a hole");
				if(!holeFound){
					//n.learningRate = 0.3f;
					holeFound = true;
				}
				//n.learningRate -= n.learningRate/700.0f;
				//n.momentum = 0.2f + i/2000.0f;
				if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			}else{
				if(print) System.out.println("updating wiehgts at random (ricochette) ->"+currQuality*mult+" "+prevQuality+" "
						+(currQuality)+" of "+ricochetteThreshold);
				//n.learningRate = 0.3f;
				n.updateWeightsAtRandom();
			}
			prevQuality = currQuality;
			
			float quality = n.calculateNNQualityAccordingToTest(input, supervised, (int)(numTotal*0.666f), numTotal);
			
			if(bestNN == null || bestNN.quality < quality){
				n.quality = quality;
				bestNN = n;
			}
			
			
			if(print) System.out.println(i+" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		System.out.println("Test precision:"+bestNN.quality+"%");
		/*int cor=0;
		int inc=0;
		for(int i=(int)(numTotal*0.666f);i<numTotal;i++){
			boolean pred = bestNN.predict(input[i]);
			if((pred && supervised[i]==1) || (!pred && supervised[i]==0)) cor++;
			else inc++;
		}
		System.out.println("Test precision:"+100.0f*cor/(cor+inc)+" Train precision:"+bestNN.quality+" Average:"+((100.0f*cor/(cor+inc)+bestNN.quality)/2)+" ");
	*/
	}
	
	
	
	
	
	
	
	
	
	
	public float getRandomNumber(float min, float max){
		//if(1==1) return 0.5f;
		Random r = new Random();
		float random = min + r.nextFloat() * (max - min);
		return random;
	}
	
	
	public void equilibrar(){
		try(BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Ramonet\\Documents\\UOC\\TFG\\Projecte\\occupancy.txt"))) {
		    List<String> positius = new ArrayList<String>();
		    List<String> negatius = new ArrayList<String>();
		    
			for(String line; (line = br.readLine()) != null; ) {
		    	String[] parts = line.split(",");
		    	line = parts[2]+","+parts[3]+","+parts[4]+","+parts[5]+","+parts[6]+","+parts[7];
		    	if(Integer.parseInt(parts[parts.length-1])==1) positius.add(line);
		    	else negatius.add(line);
		    }

			int len;
			if(positius.size() > negatius.size()) len = negatius.size();
			else len = positius.size();
	
			for(int i=0; i<len; i++){
				System.out.println(positius.get(i));
				System.out.println(negatius.get(i));
			}
			
			
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.exit(0);
	}
	
	
	
	public float[][] normalitza(float[][] input, int size, int numAt){
		for(int i = 0; i<size; i++){
			float max = -9999, min = 9999999;
			for(int j=0; j<numAt; j++){
				for(int ii=0; ii<size; ii++){
					if(input[ii][j] > max) max = input[ii][j];
					if(input[ii][j] < min) min = input[ii][j];
				}
				
				input[i][j] = (float) ((float)(input[i][j] - min)/(max-min));
			}

		}
		return input;
	}
	    
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Main m = new Main();
		//m.equilibrar();
		//System.exit(0);
		//System.out.println("ricochet......");
		for(int i=0;i<200;i++){
			
			//m.trainingSet_occupancy();
			//m.trainingSetRicochette_occupancy(m.getRandomNumber(95, 99), m.getRandomNumber(1, 15));
			//m.trainingSetRicochette_chess(m.getRandomNumber(90, 99), m.getRandomNumber(1, 15));
			//m.trainingSet_chess();
			//m.trainingSetRicochette_chess(m.getRandomNumber(80, 92), m.getRandomNumber(1, 15));
			//m.trainingSet_breastcancer();
			//m.trainingSet_breastcancer();
			//m.trainingSetRicochette_breastcancer(m.getRandomNumber(90, 99), m.getRandomNumber(1, 15));
			//m.trainingSetRicochette_breastcancer(m.getRandomNumber(60, 70), m.getRandomNumber(1, 10));
			//m.trainingSet_banknote();
			m.trainingSetRicochette_banknote(m.getRandomNumber(80, 97), m.getRandomNumber(1, 15));
			
			
			//m.trainingSet_randomdata();
			//m.trainingSetRicochette_randomdata(m.getRandomNumber(50, 60), m.getRandomNumber(1, 7));
			
			//m.trainingSet();
			//m.trainingSetRicochette(m.getRandomNumber(55, 63), m.getRandomNumber(1, 10));
			//m.trainingSet2();
			//m.trainingSet_wine();
			//m.trainingSetRicochette_wine(m.getRandomNumber(80, 97), m.getRandomNumber(1, 15));
			//m.trainingSetRicochette_banknote(65, 2);
			//m.trainingSetRicochette_banknote(65, 3);
			//m.trainingSet_breastcancer();
			//m.trainingSet_haberman();

			//m.trainingSetRicochette_haberman(m.getRandomNumber(80, 95), m.getRandomNumber(1, 10));
			//m.trainingSetRicochette_haberman(m.getRandomNumber(60, 80), m.getRandomNumber(1, 15));
			//m.trainingSetRicochette_haberman(m.getRandomNumber(60, 70), m.getRandomNumber(1, 10));
			//m.trainingSet_randomdata();
			//m.trainingSetRicochette_randomdata(m.getRandomNumber(60, 80), m.getRandomNumber(1, 15));
			//m.trainingSetRicochette_randomdata(m.getRandomNumber(50, 55), m.getRandomNumber(1, 3));
			

		}
		System.out.println("FIIIIII");
		System.exit(0);
		
		
		System.out.println("fi......");
		
		/*m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		m.trainingSetRicochette();
		System.out.println("normal......");
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();
		m.trainingSet();*/
		System.out.println("fii");
		
		System.exit(0);
		
		float input1[] = {1, 1, 0, 0, 0};
		float input2[] = {1, 1, 1, 0, 0};
		float input3[] = {1, 0, 0, 0, 1};
		float input4[] = {0, 1, 1, 0, 0};
		float input5[] = {1, 1, 1, 0, 0};
		float input6[] = {0, 0, 1, 0, 0};
		float input7[] = {0, 0, 1, 0, 1};
		float input8[] = {0, 0, 1, 1, 0};
		float input9[] = {1, 0, 0, 1, 1};
		float input10[] = {0, 0, 1, 1, 1};
		NN n = new NN(5);
		
		/*n.addSupervisedInput(input1, 1, true);
		n.calculateWeightGradients(1);
		n.printNetwork(1);
		//n.updateWeights(1, true);
		
		if(1==1) System.exit(0);
		
		n.addSupervisedInput(input2, 0, true);
		n.calculateWeightGradients(0);
		n.updateWeights(0, true);*/
		
		
		System.out.println("iniciiii");
		for(int i=0;i<30000;i++){
			if(i<20){
				try {
					Thread.sleep(100);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			n.addSupervisedInput(input1, 1, false);
			n.calculateWeightGradients(1);
			n.updateWeights(1, false);
			
			
			n.addSupervisedInput(input2, 1, false);
			n.calculateWeightGradients(1);
			n.updateWeights(1, false);
			
			n.addSupervisedInput(input3, 1, false);
			n.calculateWeightGradients(1);
			n.updateWeights(1, false);
			
			n.addSupervisedInput(input4, 1, false);
			n.calculateWeightGradients(1);
			n.updateWeights(1, false);
			
			n.addSupervisedInput(input5, 1, false);
			n.calculateWeightGradients(1);
			n.updateWeights(1, false);
			
			n.addSupervisedInput(input6, 0, false);
			n.calculateWeightGradients(0);
			n.updateWeights(0, false);
			
			n.addSupervisedInput(input7, 0, false);
			n.calculateWeightGradients(0);
			n.updateWeights(0, false);
			
			n.addSupervisedInput(input8, 0, false);
			n.calculateWeightGradients(0);
			n.updateWeights(0, false);
			
			n.addSupervisedInput(input9, 0, false);
			n.calculateWeightGradients(0);
			n.updateWeights(0, false);
			
			n.addSupervisedInput(input10, 0, false);
			n.calculateWeightGradients(0);
			n.updateWeights(0, false);
			
			System.out.println("Total error "+n.calculateTotalError(2));
			n.showNumberOfCorrectPredictions();
			
			
			n.numCorrectPredictions = n.numIncorrectPredictions = 0;
			n.totalError = 0;
		}
		
		float input11[] = {1, 1, 1, 0, 0};
		float input12[] = {1, 0, 1, 0, 0};
		float input13[] = {1, 1, 0, 0, 1};
		float input14[] = {1, 1, 1, 0, 0};
		float input15[] = {1, 1, 1, 1, 0};
		float input16[] = {0, 0, 1, 1, 0};
		float input17[] = {0, 0, 0, 0, 1};
		float input18[] = {0, 0, 0, 1, 0};
		float input19[] = {1, 0, 1, 1, 1};
		float input20[] = {0, 0, 0, 1, 1};
		
		System.out.println("Prediction: "+n.predict(input11));
		System.out.println("Prediction: "+n.predict(input12));
		System.out.println("Prediction: "+n.predict(input13));
		System.out.println("Prediction: "+n.predict(input14));
		System.out.println("Prediction: "+n.predict(input15));
		System.out.println("Prediction: "+n.predict(input16));
		System.out.println("Prediction: "+n.predict(input17));
		System.out.println("Prediction: "+n.predict(input18));
		System.out.println("Prediction: "+n.predict(input19));
		System.out.println("Prediction: "+n.predict(input20));
		
	}

}
