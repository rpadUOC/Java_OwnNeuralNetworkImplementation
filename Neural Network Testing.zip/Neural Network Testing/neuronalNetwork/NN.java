package neuronalNetwork;

import java.util.Random;

public class NN {
	float learningRate = 0.01f, momentum = 0.5f;
	int numInputs;
	int numLayers = 2;
	
	float threshold = 0.5f;
	float quality = 0;
	
	
	Connection [][][]connections;
	Neuron [][]neurons;
	
	Connection[]finalConnections;
	Neuron finalNeuron;
	
	Connection[][]bias;
	Connection finalBias;
	
	int numCorrectPredictions = 0, numIncorrectPredictions = 0;
	
	float totalError = 0;
	
	public NN(int numInputs){
		this.numInputs = numInputs;
		neurons = new Neuron[numLayers][numInputs];
		connections = new Connection[numLayers-1][numInputs][numInputs];
		finalConnections = new Connection[numInputs];
		finalNeuron = new Neuron();
		bias = new Connection[numLayers-1][numInputs]; 
		finalBias = new Connection();
		finalBias.weight = getRandomNumber(-1, 1);
		
		for(int i=0; i<numLayers; i++){
			for(int j=0; j<numInputs; j++){
				neurons[i][j] = new Neuron();
				if(i == 0){
					finalConnections[j] = new Connection();
					finalConnections[j].weight = getRandomNumber(-1, 1);
				}
				
								
				if(i<numLayers-1){
					bias[i][j] = new Connection();
					bias[i][j].weight = getRandomNumber(-1, 1);
					for(int k=0; k<numInputs; k++){
						if(i==0){
							connections[i][j][k] = new Connection();
							connections[i][j][k].weight = getRandomNumber(-1f, 1f);
						}else{
							connections[i][j][k] = new Connection();
							connections[i][j][k].weight = getRandomNumber(-1, 1);
						}
					}
				}
			}
		}
		
	}
	
	
	public void updateWeights(int supervised, boolean printScreen){
	
		for(int i=0; i<numLayers-1; i++){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					connections[i][j][k].weight = connections[i][j][k].weight - learningRate * connections[i][j][k].gradient + momentum * (connections[i][j][k].gradient-connections[i][j][k].lastGradient);
					connections[i][j][k].lastGradient = connections[i][j][k].gradient;
					
				}
				bias[i][j].weight = bias[i][j].weight - learningRate * bias[i][j].gradient + momentum * (bias[i][j].gradient-bias[i][j].lastGradient);
				bias[i][j].lastGradient = bias[i][j].gradient;
			}
		}
		for(int j=0; j<numInputs; j++){
			finalConnections[j].weight = finalConnections[j].weight - learningRate * finalConnections[j].gradient + momentum*(finalConnections[j].gradient-finalConnections[j].lastGradient);	
			finalConnections[j].lastGradient = finalConnections[j].gradient;
		}
		finalBias.weight = finalBias.weight - learningRate * finalBias.gradient + momentum * (finalBias.gradient-finalBias.lastGradient);

		finalBias.lastGradient = finalBias.gradient;
		
		for(int i=0;i<numLayers; i++){
			if(printScreen) printNetwork(supervised);
			fireLayer(i);
		}
		cleanNeuronsNetInput();
		
		//showNumberOfCorrectPredictions();
	}
	
	public void updateWeightsAtRandom(){
		float rand = 0.0f;
		for(int i=0; i<numLayers-1; i++){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					connections[i][j][k].weight = getRandomNumber(-rand, rand)+connections[i][j][k].weight - learningRate * connections[i][j][k].gradient + momentum * (connections[i][j][k].gradient-connections[i][j][k].lastGradient);
					connections[i][j][k].lastGradient = connections[i][j][k].gradient;
				}
				bias[i][j].weight = getRandomNumber(-rand, rand)+bias[i][j].weight - learningRate * bias[i][j].gradient + momentum * (bias[i][j].gradient-bias[i][j].lastGradient);
				bias[i][j].lastGradient = bias[i][j].gradient;
			}
		}
		for(int j=0; j<numInputs; j++){
			finalConnections[j].weight = getRandomNumber(-rand, rand)+finalConnections[j].weight - learningRate * finalConnections[j].gradient + momentum*(finalConnections[j].gradient-finalConnections[j].lastGradient);	
			finalConnections[j].lastGradient = finalConnections[j].gradient;
		}
		finalBias.weight = getRandomNumber(-rand, rand)+finalBias.weight - learningRate * finalBias.gradient + momentum * (finalBias.gradient-finalBias.lastGradient);
		finalBias.lastGradient = finalBias.gradient;
	}
	
	
	
	public void calculateWeightGradients(int supervisedClass){
		float delta = finalNeuron.output*(1-finalNeuron.output)*(finalNeuron.output - supervisedClass);
		float averageGradient = 0;
		int numGradients = 0;
		//gradient for weights between the final neuron and the last layer
		for(int k=0; k<numInputs; k++){
			finalConnections[k].gradient = delta * neurons[numLayers-1][k].output;
		}
		finalBias.gradient = delta;
		
		
		//gradient for weights just before the last layer
		
		for(int j=0; j<numInputs; j++){
			bias[numLayers-2][j].gradient = delta * finalConnections[j].weight * (neurons[numLayers-1][j].output * (1-neurons[numLayers-1][j].output));
			averageGradient += bias[numLayers-2][j].gradient;
			numGradients++;
			for(int k=0; k<numInputs; k++){
				connections[numLayers-2][j][k].recycledGradient = delta * finalConnections[k].weight * (neurons[numLayers-1][k].output * (1-neurons[numLayers-1][k].output));
				connections[numLayers-2][j][k].gradient = connections[numLayers-2][j][k].recycledGradient * neurons[numLayers-2][j].output;
				averageGradient += connections[numLayers-2][j][k].gradient;
				numGradients++;
			}
		}
		//System.out.println("--"+numLayers);
		//the rest of gradients
		float sumatoriPesos;
		for(int i=numLayers-3; i>=0; i--){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					sumatoriPesos = 0;
					for(int l=0; l<numInputs; l++){
						sumatoriPesos += connections[i+1][k][l].weight * connections[i+1][k][l].recycledGradient;
					}
					if(j==0){
						bias[i][j].gradient = sumatoriPesos * (neurons[i+1][k].output * (1-neurons[i+1][k].output)); 
						averageGradient += bias[i][j].gradient;
						numGradients++;
						//System.out.println("summatory!!!!!!!!! = "+sumatoriPesos);
						
					}

		
					connections[i][j][k].recycledGradient = sumatoriPesos * (neurons[i+1][k].output * (1-neurons[i+1][k].output)); 
					connections[i][j][k].gradient = connections[i][j][k].recycledGradient * neurons[i][j].output;
					averageGradient += connections[i][j][k].gradient;
					numGradients++;
					
				
				}
			}
		}
		averageGradient /= numGradients;
		//threshold -= (averageGradient-threshold)/100.0f;
		//System.out.println("threshold "+averageGradient+" "+threshold);
	}
	
	public void addSupervisedInput(float input[], int supervisedClass, boolean printScreen){
		cleanNeuronsNetInput();
		

	
		for(int j=0; j<numInputs; j++)
				neurons[0][j].output = input[j];
		//if(printScreen) printNetwork(supervisedClass);
		for(int i=0; i<numLayers; i++)
			fireLayer(i);
		if(printScreen) printNetwork(supervisedClass);
		//System.out.println("netInput "+finalNeuron.netInputSummation);
		//System.out.println(finalNeuron.output+" "+threshold+" "+supervisedClass);
		if((finalNeuron.output > threshold && supervisedClass == 1) || (finalNeuron.output <= threshold && supervisedClass == 0)){
			numCorrectPredictions++;

		}else{
			numIncorrectPredictions++;

		}
		
		totalError += Math.pow(finalNeuron.output - supervisedClass, 2);
			
	}
	
	public void cleanNeuronsNetInput(){
		//System.out.println("cleaan alll");
		for(int i=0; i<numLayers; i++){
			for(int j=0;j<numInputs; j++){
				neurons[i][j].output = 0;
			}
		}
		finalNeuron.output = 0;
	}
	
	public void showNumberOfCorrectPredictions(){
		System.out.println("Training set -> Correct:"+numCorrectPredictions+" Incorrect:"+numIncorrectPredictions+"   "+ calculateNNQuality() +"%");
	}
	
	public float calculateNNQuality(){
		return (1.0f*numCorrectPredictions/(numCorrectPredictions+numIncorrectPredictions)*100.0f);
	}

	public float calculateNNQualityAccordingToTest(float test[][], int supervised[], int start, int end){
		int correct = 0;
		int total = 0;
		for(int i = start; i<end; i++){
			if((predict(test[i]) && supervised[i]==1) || (!predict(test[i]) && supervised[i]==0)) correct++;
			total++;
		}
		return (1.0f*correct/total*100.0f);
	}
	
	
	
	public float calculateTotalError(int numLearningPatterns){
		return totalError/numLearningPatterns;
	}
	
	public void fireLayer(int layer){

		if(layer < numLayers-1){
			//if(layer < numLayers-2)
				//System.out.println("teoricament 0 "+neurons[layer+1][0].netInputSummation+" "+neurons[layer+1][2].netInputSummation);
			for(int i=0; i<numInputs; i++){
				for(int j=0;j<numInputs; j++){
					//System.out.println(neurons[layer][i].netInputSummation);
					neurons[layer+1][j].output += neurons[layer][i].output * connections[layer][i][j].weight;
				}
			}
			for(int i=0; i<numInputs; i++){
				neurons[layer+1][i].output += bias[layer][i].weight;
				//neurons[layer+1][i].netInputSummation /= numInputs+1;
				//System.out.println(neurons[layer+1][i].netInputSummation);
				neurons[layer+1][i].output = (float)(1/(1+Math.pow(Math.E, -neurons[layer+1][i].output))); 
				//System.out.println(neurons[layer+1][i].netInputSummation);
				/*if(neurons[layer+1][i].netInputSummation > 0)
					neurons[layer+1][i].netInputSummation = (float)(neurons[layer+1][i].netInputSummation);
				else
					neurons[layer+1][i].netInputSummation = -(float)(0.1f*neurons[layer+1][i].netInputSummation);
					*/
			}
		}
		else{
			for(int i=0; i<numInputs; i++){
				finalNeuron.output += neurons[numLayers-1][i].output * finalConnections[i].weight;
			}
			finalNeuron.output += finalBias.weight;
			//finalNeuron.netInputSummation /= numInputs+1;
			//System.out.println(finalNeuron.netInputSummation);
			//System.out.println((float)(1/(1+Math.pow(Math.E, -finalNeuron.netInputSummation))));
			finalNeuron.output = (float)(1/(1+Math.pow(Math.E, -finalNeuron.output))); 
			/*if(finalNeuron.netInputSummation > 0)
				finalNeuron.netInputSummation = (float)(finalNeuron.netInputSummation); 
			else
				finalNeuron.netInputSummation = -(float)(0.1f*finalNeuron.netInputSummation);*/
			
			
		}
	}
	
	public boolean predict(float input[]){
		cleanNeuronsNetInput();
		for(int j=0; j<numInputs; j++)
			neurons[0][j].output = input[j];
	
		for(int i=0; i<numLayers; i++)
			fireLayer(i);
		//System.out.println("predicttt "+finalNeuron.output);
		if(finalNeuron.output >= threshold)
			return true;
		return false;
		
	}
	
	
	public void printNetwork(int supervised){
		for(int i=0; i<numLayers; i++){
			System.out.println("_____ LAYER "+i+" _____");
			if(i<numLayers-1){
				for(int j=0; j<numInputs; j++){
					if(j==0)
						for(int k=0; k<numInputs; k++)
							System.out.println("1.0000000 _ bw:"+bias[i][k].weight+" bg:"+bias[i][k].gradient+"-> "+neurons[i+1][k].output);
					
					for(int k=0; k<numInputs; k++){
						System.out.println(neurons[i][j].output+" _w:"+connections[i][j][k].weight+" g:"+connections[i][j][k].gradient+"-> "+neurons[i+1][k].output);
					}
				}
			}
			else{
				System.out.println("1.0000000 _fbw:"+finalBias.weight+" fbg:"+finalBias.gradient+"-> "+finalNeuron.output);
				for(int j=0; j<numInputs; j++){
					System.out.println(neurons[numLayers-1][j].output+" _fw:"+finalConnections[j].weight+" fg:"+finalConnections[j].gradient+"-> "+finalNeuron.output+"   "+supervised);
				}
			}
		}
	}
	
	public float getRandomNumber(float min, float max){
		//if(1==1) return 0.5f;
		
		Random r = new Random();
		float random = min + r.nextFloat() * (max - min);
		return random;
	}
	
	
}
