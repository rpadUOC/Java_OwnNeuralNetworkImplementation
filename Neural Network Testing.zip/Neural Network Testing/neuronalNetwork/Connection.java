package neuronalNetwork;

public class Connection {
	float weight;
	float gradient;
	float lastGradient;
	float recycledGradient;
	@Override
	public String toString() {
		return "Connection [weight=" + weight + ", gradient=" + gradient
				+ ", lastGradient=" + lastGradient + ", recycledGradient="
				+ recycledGradient + "]";
	}
	
	
	
	

}
