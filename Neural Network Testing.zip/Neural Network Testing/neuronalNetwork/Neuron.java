package neuronalNetwork;

public class Neuron {
	float output;

	@Override
	public String toString() {
		return "Neuron [netInputSummation=" + output + "]";
	}
	
	
	
	
}
