package SQL;

import java.util.List;

public class SQLSentence {
	String sql;
	List<Object> atributs;
	public SQLSentence(String sql, List<Object> atributs) {
		this.sql = sql;
		this.atributs = atributs;
	}
	public String getSql() {
		return sql;
	}
	public void setSql(String sql) {
		this.sql = sql;
	}
	public List<Object> getAtributs() {
		return atributs;
	}
	public void setAtributs(List<Object> atributs) {
		this.atributs = atributs;
	}
		
	
}
