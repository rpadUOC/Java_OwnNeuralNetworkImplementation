package SQL;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;


public class SqlManager {
	
	private Connection con;
	private Statement query;
	private ResultSet resultSet;
	private PreparedStatement prep;
	private final Object lock = new Object();
	
	public SqlManager(){
		//We disconnect from database
		try {
			if(query != null) query.close();
			if(con != null) con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		//Connect again
		try { 
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://192.168.1.20:5432/AttentionalControl","postgres", "ramonUoc18");
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}
	
	public synchronized boolean SqlUpdate(SQLSentence sentence){
		synchronized (lock) {
			try {
			prep = con.prepareStatement(sentence.getSql());
			List<Object> atributs = sentence.getAtributs();
			for(int i=0;i< atributs.size(); i++){
				if(atributs.get(i) instanceof String) prep.setString(i+1, (String)atributs.get(i));
				else if(atributs.get(i) instanceof Integer) prep.setInt(i+1, (Integer)atributs.get(i));
			}
			if(prep.executeUpdate() == 1) return true;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
	}
	
	public synchronized ResultSet SqlSelect(SQLSentence sentence){
		synchronized (lock) {
						
			try {
				prep = con.prepareStatement(sentence.getSql());
				List<Object> atributs = sentence.getAtributs();
				for(int i=0;i< atributs.size(); i++){
					if(atributs.get(i) instanceof String) prep.setString(i+1, (String)atributs.get(i));
					else if(atributs.get(i) instanceof Integer) prep.setInt(i+1, (Integer)atributs.get(i));
				}
				resultSet = prep.executeQuery();
				return resultSet;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			return null;
		}
	}
	
}
