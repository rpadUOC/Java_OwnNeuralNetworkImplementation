package NeuralNetwork;

public class Connection {
	private float weight;
	private float gradient;
	private float lastGradient;
	private float recycledGradient;
	
	
	
	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public float getGradient() {
		return gradient;
	}


	public void setGradient(float gradient) {
		this.gradient = gradient;
	}

	public float getLastGradient() {
		return lastGradient;
	}

	public void setLastGradient(float lastGradient) {
		this.lastGradient = lastGradient;
	}

	public float getRecycledGradient() {
		return recycledGradient;
	}

	public void setRecycledGradient(float recycledGradient) {
		this.recycledGradient = recycledGradient;
	}

	
	@Override
	public String toString() {
		return "Connection [weight=" + weight + ", gradient=" + gradient
				+ ", lastGradient=" + lastGradient + ", recycledGradient="
				+ recycledGradient + "]";
	}
	
	
	
	

}
