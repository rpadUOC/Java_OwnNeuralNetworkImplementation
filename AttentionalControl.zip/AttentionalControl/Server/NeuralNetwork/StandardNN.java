package NeuralNetwork;

public class StandardNN extends NNManager{
	
	public float getLearningRate() {
		return learningRate;
	}

	public void setLearningRate(float learningRate) {
		this.learningRate = learningRate;
	}

	public float getMomentum() {
		return momentum;
	}

	public void setMomentum(float momentum) {
		this.momentum = momentum;
	}

	@Override
	public void setGentics(int typeOfDataTransformation, int numLayers, float learningRate, float momentum, float... others) {
		this.typeOfDataTransformation = typeOfDataTransformation;
		this.learningRate = learningRate;
		this.momentum = momentum;
		this.numLayers = numLayers;
	}
	
	

	@Override
	public void run() {
		//entrenem
		n = new NN(numAttributes, numLayers, numTestPatterns+numTrainPatterns);
		bestNN = new NN(numAttributes, numLayers, numTestPatterns+numTrainPatterns);
		n.learningRate = learningRate;
		n.momentum = momentum;
		if(print) System.out.println("l:"+n.learningRate+" m:"+n.momentum);
			
		int timeToBreathCounter = 0;
		
		while(!isTrainingTimeExhausted()){
			if(timeToBreathCounter++ > 10000){
				try {
					Thread.sleep(getTimeToBreathe()); //We sleep according to the cpu usage by this app
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				timeToBreathCounter = 0;
			}
				
			for(int j=0;j<numTrainPatterns;j++){
				int supervised = (int)trainMatrix[j][numAttributes];
				n.addSupervisedInput(trainMatrix[j], supervised, false);
				n.calculateWeightGradients(supervised);
				n.updateWeights(supervised, false);
			}
			
			float quality = n.calculateNNQualityAccordingToTest(testMatrix, numAttributes, numTestPatterns, bestNN);
			
			
			if(print) System.out.println("Prediction test: "+quality+" train:"+n.calculateNNQuality());
			
			
			
			if(bestNN == null || bestNN.getNNQuality() < quality){
				n.setNNQuality(quality);
				bestNN = n;
			}
			
			if(print) System.out.println(" Total error "+n.calculateTotalError(951));
			if(print) n.showNumberOfCorrectPredictions();
			
			
			n.resetQualityCounters();
		}
		
		
		if(print) System.out.println("Best quality achieved: "+bestNN.getNNQuality());
		setEnded();
	}
	
}
