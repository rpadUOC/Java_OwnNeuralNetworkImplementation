package NeuralNetwork;

import java.util.Random;

public class NN {
	float learningRate = 0.02f, momentum = 0.5f;
	private int numInputs;
	private int numLayers;
	private int sampleSize;
	
	private float threshold = 0.5f;
	private float quality = 0;
	
	
	private Connection [][][]connections;
	private Neuron [][]neurons;
	
	private Connection[]finalConnections;
	private Neuron finalNeuron;
	
	private Connection[][]bias;
	private Connection finalBias;
	
	private int numCorrectPredictions = 0, numIncorrectPredictions = 0;
	private float totalError = 0;
	
	public void resetQualityCounters(){
		totalError = numCorrectPredictions = numIncorrectPredictions = 0;
	}
	
	public void setNumLayers(int layers){
		numLayers = layers;
		System.out.println("numlayers "+numLayers);
	}
	
	public int getNumLayers(){
		return numLayers;
	}
	
	public float getNNQuality(){
		return quality;
	}
	
	public void setNNQuality(float quality){
		this.quality = quality;
	}
	
	public int getSampleSize(){
		return sampleSize;
	}
	
	
	public NN(int numInputs, int numLayers, int sampleSize){
		this.numInputs = numInputs;
		this.numLayers = numLayers;
		this.sampleSize = sampleSize;
		neurons = new Neuron[numLayers][numInputs];
		connections = new Connection[numLayers-1][numInputs][numInputs];
		finalConnections = new Connection[numInputs];
		finalNeuron = new Neuron();
		bias = new Connection[numLayers-1][numInputs]; 
		finalBias = new Connection();
		finalBias.setWeight(getRandomNumber(-1, 1));
		
		for(int i=0; i<numLayers; i++){
			for(int j=0; j<numInputs; j++){
				neurons[i][j] = new Neuron();
				if(i == 0){
					finalConnections[j] = new Connection();
					finalConnections[j].setWeight(getRandomNumber(-1, 1));
				}
				
								
				if(i<numLayers-1){
					bias[i][j] = new Connection();
					bias[i][j].setWeight(getRandomNumber(-1, 1));
					for(int k=0; k<numInputs; k++){
						connections[i][j][k] = new Connection();
						connections[i][j][k].setWeight(getRandomNumber(-1, 1));
					}
				}
			}
		}
		
	}
	
	
	public void updateWeights(int supervised, boolean printScreen){
	
		for(int i=0; i<numLayers-1; i++){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					connections[i][j][k].setWeight(connections[i][j][k].getWeight() - learningRate * connections[i][j][k].getGradient() + momentum * (connections[i][j][k].getGradient()-connections[i][j][k].getLastGradient()));
					connections[i][j][k].setLastGradient(connections[i][j][k].getGradient());
				}
				bias[i][j].setWeight(bias[i][j].getWeight() - learningRate * bias[i][j].getGradient() + momentum * (bias[i][j].getGradient()-bias[i][j].getLastGradient()));
				bias[i][j].setLastGradient(bias[i][j].getGradient());
			}
		}
		for(int j=0; j<numInputs; j++){
			finalConnections[j].setWeight(finalConnections[j].getWeight() - learningRate * finalConnections[j].getGradient() + momentum*(finalConnections[j].getGradient()-finalConnections[j].getLastGradient()));	
			finalConnections[j].setLastGradient(finalConnections[j].getGradient());
		}
		finalBias.setWeight(finalBias.getWeight() - learningRate * finalBias.getGradient() + momentum * (finalBias.getGradient()-finalBias.getLastGradient()));

		finalBias.setLastGradient(finalBias.getGradient());
		cleanNeuronsNetInput();
		for(int i=0;i<numLayers; i++){
			if(printScreen) printNetwork(supervised);
			fireLayer(i);
		}
	}
	
	public void updateWeightsAtRandom(){
		float rand = 0.0f;
		for(int i=0; i<numLayers-1; i++){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					connections[i][j][k].setWeight(getRandomNumber(-rand, rand)+connections[i][j][k].getWeight() - learningRate * connections[i][j][k].getGradient() + momentum * (connections[i][j][k].getGradient()-connections[i][j][k].getLastGradient()));
					connections[i][j][k].setLastGradient(connections[i][j][k].getGradient());
				}
				bias[i][j].setWeight(getRandomNumber(-rand, rand)+bias[i][j].getWeight() - learningRate * bias[i][j].getGradient() + momentum * (bias[i][j].getGradient()-bias[i][j].getLastGradient()));
				bias[i][j].setLastGradient(bias[i][j].getGradient());
			}
		}
		for(int j=0; j<numInputs; j++){
			finalConnections[j].setWeight(getRandomNumber(-rand, rand)+finalConnections[j].getWeight() - learningRate * finalConnections[j].getGradient() + momentum*(finalConnections[j].getGradient()-finalConnections[j].getLastGradient()));	
			finalConnections[j].setLastGradient(finalConnections[j].getGradient());
		}
		finalBias.setWeight(getRandomNumber(-rand, rand)+finalBias.getWeight() - learningRate * finalBias.getGradient() + momentum * (finalBias.getGradient()-finalBias.getLastGradient()));
		finalBias.setLastGradient(finalBias.getGradient());
	}
	
	
	
	public void calculateWeightGradients(int supervisedClass){
		float delta = finalNeuron.getOutput()*(1-finalNeuron.getOutput())*(finalNeuron.getOutput() - supervisedClass);
		float averageGradient = 0;
		int numGradients = 0;
		//gradient for weights between the final neuron and the last layer
		for(int k=0; k<numInputs; k++){
			finalConnections[k].setGradient(delta * neurons[numLayers-1][k].getOutput());
		}
		finalBias.setGradient(delta);
		
		
		//gradient for weights just before the last layer
		
		for(int j=0; j<numInputs; j++){
			bias[numLayers-2][j].setGradient(delta * finalConnections[j].getWeight() * (neurons[numLayers-1][j].getOutput() * (1-neurons[numLayers-1][j].getOutput())));
			averageGradient += bias[numLayers-2][j].getGradient();
			numGradients++;
			for(int k=0; k<numInputs; k++){
				connections[numLayers-2][j][k].setRecycledGradient(delta * finalConnections[k].getWeight() * (neurons[numLayers-1][k].getOutput() * (1-neurons[numLayers-1][k].getOutput())));
				connections[numLayers-2][j][k].setGradient(connections[numLayers-2][j][k].getRecycledGradient() * neurons[numLayers-2][j].getOutput());
				averageGradient += connections[numLayers-2][j][k].getGradient();
				numGradients++;
			}
		}
		
		//the rest of gradients
		float sumatoriPesos;
		for(int i=numLayers-3; i>=0; i--){
			for(int j=0; j<numInputs; j++){
				for(int k=0; k<numInputs; k++){
					sumatoriPesos = 0;
					for(int l=0; l<numInputs; l++){
						sumatoriPesos += connections[i+1][k][l].getWeight() * connections[i+1][k][l].getRecycledGradient();
					}
					if(j==0){
						bias[i][j].setGradient(sumatoriPesos * (neurons[i+1][k].getOutput() * (1-neurons[i+1][k].getOutput()))); 
						averageGradient += bias[i][j].getGradient();
						numGradients++;
						//System.out.println("summatory!!!!!!!!! = "+sumatoriPesos);
						
					}
					
					connections[i][j][k].setRecycledGradient(sumatoriPesos * (neurons[i+1][k].getOutput() * (1-neurons[i+1][k].getOutput()))); 
					connections[i][j][k].setGradient(connections[i][j][k].getRecycledGradient() * neurons[i][j].getOutput());
					averageGradient += connections[i][j][k].getGradient();
					numGradients++;
				}
			}
		}
		
		averageGradient /= numGradients;
		//threshold -= (averageGradient-threshold)/100.0f;
		//System.out.println("threshold "+averageGradient+" "+threshold);
	}
	
	public void addSupervisedInput(float input[], int supervisedClass, boolean printScreen){
		cleanNeuronsNetInput();
		
		for(int j=0; j<numInputs; j++)
				neurons[0][j].setNetInputSummation(input[j]);
		//if(printScreen) printNetwork(supervisedClass);
		for(int i=0; i<numLayers; i++)
			fireLayer(i);
		if(printScreen) printNetwork(supervisedClass);
		//System.out.println("netInput "+finalNeuron.netInputSummation);
		if((finalNeuron.getOutput() > threshold && supervisedClass == 1) || (finalNeuron.getOutput() <= threshold && supervisedClass == 0)){
			numCorrectPredictions++;

		}else{
			numIncorrectPredictions++;

		}
		if(printScreen) System.out.println("correct: "+numCorrectPredictions+" incorrect:"+numIncorrectPredictions);
		totalError += Math.pow(finalNeuron.getOutput() - supervisedClass, 2);
			
	}
	
	public void cleanNeuronsNetInput(){
		for(int i=0; i<numLayers; i++){
			for(int j=0;j<numInputs; j++){
				neurons[i][j].setNetInputSummation(0);
			}
		}
		finalNeuron.setNetInputSummation(0);
	}
	
	public void showNumberOfCorrectPredictions(){
		System.out.println("Correct:"+numCorrectPredictions+" Incorrect:"+numIncorrectPredictions+"   "+ calculateNNQuality() +"%");
	}
	
	public float calculateNNQuality(){
		return (1.0f*numCorrectPredictions/(numCorrectPredictions+numIncorrectPredictions)*100.0f);
	}
	
	public float calculateNNQualityAccordingToTest(float test[][], int numAttributes, int size, NN bestNN){
		int cor = 0;
		int inc = 0;
		for(int i = 0; i<size; i++){
			boolean pred = bestNN.predict(test[i]);
			if((pred && test[i][numAttributes]==1) || (!pred && test[i][numAttributes]==0)) cor++;
			else inc++;
		}
		return ((100.0f*cor)/(cor+inc)*1.0f);
	}
	

	
	
	
	public float calculateTotalError(int numLearningPatterns){
		return totalError/numLearningPatterns;
	}
	
	public void fireLayer(int layer){
		if(layer < numLayers-1){
			for(int i=0; i<numInputs; i++){
				for(int j=0;j<numInputs; j++){
					neurons[layer+1][j].setNetInputSummation(neurons[layer+1][j].getOutput() + neurons[layer][i].getOutput() * connections[layer][i][j].getWeight());
				}
			}
			for(int i=0; i<numInputs; i++){
				neurons[layer+1][i].setNetInputSummation(neurons[layer+1][i].getOutput() + bias[layer][i].getWeight());
				//neurons[layer+1][i].netInputSummation /= numInputs;
				neurons[layer+1][i].setNetInputSummation((float)(1/(1+Math.pow(Math.E, -neurons[layer+1][i].getOutput())))); 
			}
		}
		else{
			for(int i=0; i<numInputs; i++){
				finalNeuron.setNetInputSummation(finalNeuron.getOutput() + neurons[numLayers-1][i].getOutput() * finalConnections[i].getWeight());
			}
			finalNeuron.setNetInputSummation(finalNeuron.getOutput() + finalBias.getWeight());
			//finalNeuron.netInputSummation /= numInputs;
			finalNeuron.setNetInputSummation((float)(1/(1+Math.pow(Math.E, -finalNeuron.getOutput())))); 
		}
	}
	
	public boolean predict(float input[]){

		cleanNeuronsNetInput();

		for(int j=0; j<numInputs; j++)
			neurons[0][j].setNetInputSummation(input[j]);

		for(int i=0; i<numLayers; i++)
			fireLayer(i);

		if(finalNeuron.getOutput() >= threshold)
			return true;
		return false;
		
	}
	
	
	
	public void printNetwork(int supervised){
		for(int i=0; i<numLayers; i++){
			System.out.println("_____ LAYER "+i+" _____");
			if(i<numLayers-1){
				for(int j=0; j<numInputs; j++){
					if(j==0)
						for(int k=0; k<numInputs; k++)
							System.out.println("1.0000000 _ bw:"+bias[i][k].getWeight()+" bg:"+bias[i][k].getGradient()+"-> "+neurons[i+1][k].getOutput());
					
					for(int k=0; k<numInputs; k++){
						System.out.println(neurons[i][j].getOutput()+" _w:"+connections[i][j][k].getWeight()+" g:"+connections[i][j][k].getGradient()+"-> "+neurons[i+1][k].getOutput());
					}
				}
			}
			else{
				System.out.println("1.0000000 _fbw:"+finalBias.getWeight()+" fbg:"+finalBias.getGradient()+"-> "+finalNeuron.getOutput());
				for(int j=0; j<numInputs; j++){
					System.out.println(neurons[numLayers-1][j].getOutput()+" _fw:"+finalConnections[j].getWeight()+" fg:"+finalConnections[j].getGradient()+"-> "+finalNeuron.getOutput()+"   "+supervised);
				}
			}
		}
	}
	
	public float getRandomNumber(float min, float max){
		//if(1==1) return 0.5f;
		Random r = new Random();
		float random = min + r.nextFloat() * (max - min);
		return random;
	}
	
	
}
