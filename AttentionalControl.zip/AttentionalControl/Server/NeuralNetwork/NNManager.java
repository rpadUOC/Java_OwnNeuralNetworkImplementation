package NeuralNetwork;

import java.awt.Point;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import source.Globals;

import Data.RawPattern;

public abstract class NNManager implements Runnable{
	protected NN n;
	protected NN bestNN = null;
	protected boolean print = false;
	protected int numAttributes = RawPattern.numAttributes;
	protected float trainMatrix[][];
	protected float testMatrix[][];
	protected int numTrainPatterns;
	protected int numTestPatterns;
	
	protected float learningRate;
	protected float momentum;
	protected int numLayers;
	protected int typeOfDataTransformation=-1;
	
	private int numOfNetworksInGeneration;	
	private Timestamp startTime;
	
	private int timeToBreathe;
	float timeToBreatheStepMultiplier = 1.01f;
	Object lock_speed = new Object();
	
	

	public int getTimeToBreathe(){
		synchronized(lock_speed){
			return timeToBreathe;
		}
	}
	
	public void goFaster(){
		synchronized(lock_speed){
			timeToBreathe /= timeToBreatheStepMultiplier;
			if(timeToBreathe < 2)
				timeToBreathe = 2;
		}
	}
	
	public void slowDown(){
		synchronized(lock_speed){
			timeToBreathe *= timeToBreatheStepMultiplier;
			if(timeToBreathe > 10000)
				timeToBreathe = 10000;
		}
	}
	
	public NN getBestNN(){
		return bestNN;
	}
	
	public NNManager(){
		startTime = new Timestamp(System.currentTimeMillis());
		numOfNetworksInGeneration = Globals.numOfNNInGeneration;
		timeToBreathe = (int)((100/Globals.maxAppAllowedCPUUsage)*numOfNetworksInGeneration);	//This is a VERY approximate calculation, just to start "more or less" on the desired cpu usage 
	}
	
	public void setNumLayers(int layers){
		this.numLayers = layers;
	}
	
	public int getNumberOfLayers(){
		return n.getNumLayers();
	}
	
	public void setTypeOfDataTransofrmation(int type){
		typeOfDataTransformation = type;
	}
	
	public int getTypeOfDataTransofrmation(){
		return typeOfDataTransformation;
	}
	
	public boolean isTrainingTimeExhausted(){
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		if((int)((currentTime.getTime() - startTime.getTime())/1000) > Globals.timeToTrain) return true;
		else return false;
	}

	
	
	boolean ended = false;
	Object end_lock = new Object();
	
	public boolean isEnded(){
		synchronized(end_lock){
			return ended;
		}
	}
	
	public void setEnded(){
		synchronized(end_lock){
			ended = true;
		}
	}
	
	
	public abstract void setGentics(int typeOfDataTransformation, int numLayers, float learningRate, float momentum, float... others);
	
	public void loadPatternsToNN(List<RawPattern> patterns){
		List<RawPattern> trainPatterns = new ArrayList<RawPattern>();
		List<RawPattern> testPatterns = new ArrayList<RawPattern>();
		int numPat = patterns.size();
		for(int i=0; i<numPat; i++){
			if(i%5 == 0)	// A 1/5 of the patterns will be used as test set, the rest as train set
				testPatterns.add(patterns.get(i));	
			else
				trainPatterns.add(patterns.get(i));
		}
		
		numTrainPatterns = trainPatterns.size();
		numTestPatterns = testPatterns.size();
		
		//n = new NN(numTrainPatterns);
		trainMatrix = new float[trainPatterns.size()][numAttributes+1];
		for(int i=0;i<numTrainPatterns;i++)
			trainMatrix[i] = new float[numAttributes+1];
		
		testMatrix = new float[testPatterns.size()][numAttributes+1];
		for(int i=0;i<numTestPatterns;i++)
			testMatrix[i] = new float[numAttributes+1];

		
		
		//loading data from lists to float matrixes for efficience reasons
		for(int i=0;i<numTrainPatterns; i++){
			RawPattern trainP = trainPatterns.get(i);
			trainMatrix[i][0] = trainP.getAppExecutionTime();
			trainMatrix[i][1] = trainP.getAverageActivityLevel();
			trainMatrix[i][2] = trainP.getAverageDistanceFromScreen();
			trainMatrix[i][3] = trainP.getAverageFaceMovement();
			trainMatrix[i][4] = trainP.getDayOfTheWeek();
			trainMatrix[i][5] = trainP.getDayTime();
			trainMatrix[i][6] = trainP.getEndedWithDistraction()-1;
		}
		
		for(int i=0;i<numTestPatterns; i++){
			RawPattern testP = testPatterns.get(i);
			testMatrix[i][0] = testP.getAppExecutionTime();
			testMatrix[i][1] = testP.getAverageActivityLevel();
			testMatrix[i][2] = testP.getAverageDistanceFromScreen();
			testMatrix[i][3] = testP.getAverageFaceMovement();
			testMatrix[i][4] = testP.getDayOfTheWeek();
			testMatrix[i][5] = testP.getDayTime();
			testMatrix[i][6] = testP.getEndedWithDistraction()-1;
		}
		

		if(Globals.normalize == typeOfDataTransformation)
			normalizeData();
		else
			standarizeData();
			
	}
	
	public void normalizeData(){
		for(int i = 0; i<numAttributes; i++){
			Point2D.Double maxMin = getMaxAndMin(i);
			if(maxMin.getX() == maxMin.getY())
				continue;
			for(int j=0; j<numTrainPatterns; j++){
				trainMatrix[j][i] = (float) ((float)(trainMatrix[j][i] - maxMin.getY())/(maxMin.getX()-maxMin.getY()));
			}
			for(int j=0; j<numTestPatterns; j++){
				testMatrix[j][i] = (float) ((float)(testMatrix[j][i] - maxMin.getY())/(maxMin.getX()-maxMin.getY()));
			}
		}
	}
	
	public void standarizeData(){
		for(int i = 0; i<numAttributes; i++){
			Point2D.Double maxMin = getMaxAndMin(i);
			if(maxMin.getX() == maxMin.getY())
				continue;
			float average = 0;
			for(int j=0; j<numTrainPatterns; j++)
				average += trainMatrix[j][i];
			for(int j=0; j<numTestPatterns; j++)
				average += testMatrix[j][i];
			average /=numTrainPatterns+numTestPatterns;
			
			float desvStd = 0;
			for(int j=0; j<numTrainPatterns; j++){
				desvStd += Math.pow(trainMatrix[j][i]-average, 2);
			}
			for(int j=0; j<numTestPatterns; j++){
				desvStd += Math.pow(testMatrix[j][i]-average, 2);
			}
			desvStd /=numTrainPatterns+numTestPatterns;
			desvStd = (float) Math.sqrt(desvStd);
			
			for(int j=0; j<numTrainPatterns; j++){
				trainMatrix[j][i] = (trainMatrix[j][i] - average) / desvStd;
			}
			
			for(int j=0; j<numTestPatterns; j++){
				testMatrix[j][i] = (testMatrix[j][i] - average) / desvStd;
			}
			
		}
	}

	public Point2D.Double getMaxAndMin(int numAttribute){
		float max = -9999, min = 9999999;
		for(int i=0; i<numTrainPatterns; i++){
			if(trainMatrix[i][numAttribute] > max) max = trainMatrix[i][numAttribute];
			if(trainMatrix[i][numAttribute] < min) min = trainMatrix[i][numAttribute];
		}
		for(int i=0; i<numTestPatterns; i++){
			if(testMatrix[i][numAttribute] > max) max = testMatrix[i][numAttribute];
			if(testMatrix[i][numAttribute] < min) min = testMatrix[i][numAttribute];
		}
		return new Point2D.Double(max, min);
	}
	
	
}
