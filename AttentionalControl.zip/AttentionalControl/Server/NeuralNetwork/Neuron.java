package NeuralNetwork;

public class Neuron {
	private float output;

	public float getOutput(){
		return output;
	}
	
	public void setNetInputSummation(float value){
		output = value;
	}
	
	@Override
	public String toString() {
		return "Neuron [netInputSummation=" + output + "]";
	}
	
	
	
	
}
