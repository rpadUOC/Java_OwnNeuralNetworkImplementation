package SocketsWithClient;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Data.ClientRequest;
import Data.RawPattern;
import Prediction.PredictionManager;
import SQL.SQLSentence;
import SQL.SqlManager;

import source.Globals;



public class ServerSocket {
	private SqlManager sqlm;
	private List<Object> attributes;
	private PredictionManager pm;
	
	public ServerSocket(){
		attributes = new ArrayList<Object>();
		sqlm = new SqlManager();	// Connection to PostgreSQL stablished!
		pm = new PredictionManager(getAllPatternsFromDB());
	}
	
	private synchronized List<RawPattern> getAllPatternsFromDB(){
		attributes.clear();
		ResultSet rs = sqlm.SqlSelect(new SQLSentence("select * from Patterns", attributes));
		List<RawPattern> patterns = new ArrayList<RawPattern>();
		try {
			while(rs.next()){
				//id serial primary key, aFaceMovement int, aDistanceFromScreen int, aActivityLevel int, appExecutionTime int, 
				//dayTime int, dayOfWeek int, isDistraction int
				patterns.add(new RawPattern(rs.getInt(2), rs.getInt(3), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(7), rs.getInt(8)));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return patterns;
	}
	
	public synchronized int getNeededPatternInDB(){	//What kind of pattern (positive/negative) do we need?
		attributes.clear();
		ResultSet rs = sqlm.SqlSelect(new SQLSentence("select count(*) from Patterns where isDistraction = 1", attributes));
		try {
			int numPositive;
			if(rs.next()){
				numPositive = rs.getInt(1);
				ResultSet rs2 = sqlm.SqlSelect(new SQLSentence("select count(*) from Patterns where isDistraction = 2", attributes));
				if(rs2.next()){
					if(numPositive - rs2.getInt(1) < 0) //if there are more negatives than positives
						return Globals.positive; // we need positive patterns
					else
						return Globals.negative;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return Globals.nothing_to_do;
	}
	
	public synchronized void insertNewPatternToDB(ClientRequest cr){	// We add a new pattern (positive/negative) to DB
		//fer insert corresponent
		RawPattern rp = cr.getPattern();
		if(rp.getEndedWithDistraction() != Globals.nothing_to_do){
			attributes.clear();
			attributes.add(rp.getAverageFaceMovement());
			attributes.add(rp.getAverageDistanceFromScreen());
			attributes.add(rp.getAverageActivityLevel());
			attributes.add(rp.getAppExecutionTime());
			attributes.add(rp.getDayTime());
			attributes.add(rp.getDayOfTheWeek());
			attributes.add(rp.getEndedWithDistraction());
			//id serial primary key, aFaceMovement int, aDistanceFromScreen int, aActivityLevel int, appExecutionTime int, 
			//dayTime int, dayOfWeek int, isDistraction int
			sqlm.SqlUpdate(new SQLSentence("insert into Patterns(aFaceMovement,aDistanceFromScreen,aActivityLevel,appExecutionTime,dayTime,dayOfWeek,isDistraction) values(?,?,?,?,?,?,?)", attributes));
			pm.addPattern(rp);
		}
	}
	
	public synchronized int predictPattern(ClientRequest cr){
		if(pm.predictPattern(cr))
			return Globals.positive;
		else 
			return Globals.negative;
	}
	
	public void runMultiSocket(){
		java.net.ServerSocket server = null;
		try {
			server = new java.net.ServerSocket(Globals.Server_Port);
			
			while(true) 
			{
				System.out.println("Esperant el client  ");
				Thread thread = new Thread(new SocketWithClient(server.accept(), this));
				thread.start(); //WE OPEN A NEW SOCKET FOR THE CONNECTED CLIENT  

			}       
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		ServerSocket ss = new ServerSocket();
		ss.runMultiSocket();    
	}  
}
