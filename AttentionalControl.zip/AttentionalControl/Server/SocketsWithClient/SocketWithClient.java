package SocketsWithClient;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;

import source.Globals;

import Data.ClientRequest;
import Data.ServerResponse;






public class SocketWithClient implements Runnable{
		private ObjectInputStream in = null;
		private ObjectOutputStream out = null;
	    private Socket socket = null;
	    private boolean keepConnection = true;
	    private int socketFails = 0;	//if socket has failed 10 times without stop we close this thread
	    
	    private ServerSocket serverSocket;
	    
	    public SocketWithClient(Socket clientConnectat, ServerSocket serverSocket)
	    {
	    	this.socket = clientConnectat;
	    	this.serverSocket = serverSocket; 
	    }
	    
		@Override
		public void run() {
			try {
				Thread.sleep(500);
			} catch (InterruptedException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			try{
		    	out = new ObjectOutputStream(socket.getOutputStream());
			    in = new ObjectInputStream(socket.getInputStream());
			    
			    while(keepConnection)
			    { 
			    	try{
			    		//System.out.println("llegint");
			    		ClientRequest req = (ClientRequest) in.readObject();
			    		//System.out.println("llegit");
				    	System.out.println("Rebent del client: \n\t" + req.toString());
				    	
				    	try {
							Thread.sleep(100);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace(); 
						}
				    	if(req.getRequest() == Globals.request_what_training_patterns_do_you_need){ //what patterns are needed?
				    		System.out.println("server- what patterns are needed?");
				    		out.writeObject(new ServerResponse(Globals.request_what_training_patterns_do_you_need, serverSocket.getNeededPatternInDB()));
				    	}
				    	else if(req.getRequest() == Globals.request_i_send_new_training_pattern){ //new pattern to learn
				    		System.out.println("server - new pattern to learn");
				    		serverSocket.insertNewPatternToDB(req);
				    		out.writeObject(new ServerResponse(Globals.request_i_send_new_training_pattern, Globals.nothing_to_do));
				    	}
				    	else if(req.getRequest() == Globals.request_prediction){ //predict
				    		System.out.println("server -we are going to predict");
				    		out.writeObject(new ServerResponse(Globals.request_prediction, serverSocket.predictPattern(req)));
				    	}
				    	System.out.println("sent");
				    	
				    	
				    	
				    	if(socketFails != 0) 
			    			socketFails = 0;
			    	} catch (IOException | ClassNotFoundException e) {
			    		socketFails++;
			    		if(socketFails >= 10) 
			    			keepConnection = false;	//CONNECTION IS LOST (END OF THREAD)
					}
			    }
			} catch (IOException e) {
				e.printStackTrace();
			}
		    try {//CLOSE
				in.close();
			    out.close();
			    socket.close();
		    } catch (IOException e) {
				e.printStackTrace();
			}
		    System.out.println("END OF THREAD (SocketAmbClient)");
		}
	    
	    
	    
	    
}
