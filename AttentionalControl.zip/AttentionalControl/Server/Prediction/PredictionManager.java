package Prediction;

import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import source.Globals;

import Data.ClientRequest;
import Data.RawPattern;
import NeuralNetwork.NN;
import NeuralNetwork.NNManager;
import NeuralNetwork.RicochetNN;
import NeuralNetwork.StandardNN;


public class PredictionManager {
	private List<RawPattern> patterns;
	GeneticAlgorithm ga;
	
	public PredictionManager(List<RawPattern> rawPatterns){
		patterns = Collections.synchronizedList(new ArrayList<RawPattern>());
		patterns.addAll(rawPatterns);
		ga = new GeneticAlgorithm();
		Thread genAlg_thread = new Thread(ga);
		genAlg_thread.start();
	}
	
	public class GeneticAlgorithm implements Runnable {
		
		NN bestNeuralNetworksEver[];	//All the Einsteins, Nikola Teslas, Gaudis, Ada Byrons, Mozarts, Da vincis... stay here and will be used to predict!
		NNManager generationOfNN[];
		
		public GeneticAlgorithm(){
			bestNeuralNetworksEver = new NN[Globals.numOfBestNN];
			generationOfNN = new NNManager[Globals.numOfNNInGeneration];
		}
		
		public float getRandomNumber(float min, float max){
			Random r = new Random();
			float random = min + r.nextFloat() * (max - min);
			return random;
		}
		
		public int getRandomIntegerNumber(int min, int max){
			Random r = new Random();
			int random = r.nextInt(max-min+1) + min;
			return random;
		}
		
		public float getRandomLearningRate(float previous){
			float rand = getRandomNumber(0.0001f, 1f);
			if(previous == 0) //no previous learning rate defined
				return rand;
			else
				return (previous-rand)/50+previous;
		}
		
		public float getRandomMomentum(float previous){
			float rand = getRandomNumber(0.01f, 1f);
			if(previous == 0) //no previous momentum defined
				return rand;
			else
				return (previous-rand)/5+previous;
		}
		
		public float getRandomRicochetSlopeThreshold(float previous){
			float rand = getRandomNumber(0.5f, 10f);
			if(previous == 0) //no previous ricochet slope threshold defined
				return rand;
			else
				return (previous-rand)/3+previous;
		}
		
		public float getRandomRicochetThreshold(float previous){
			float rand = getRandomNumber(50, 80);
			if(previous == 0) //no previous ricochet threshold defined
				return rand;
			else
				return (previous-rand)/10+previous;
		}
		
		public int getRandomNumberOfLayers(){
			return getRandomIntegerNumber(2, 5);
		}
		
		public int getRandomTypeOfDataTransformation(){
			return getRandomIntegerNumber(Globals.standarize, Globals.normalize);
		}
		
		public NNManager getRandomNNWithRandomGenetics(){
			NNManager nnm = NeuralNetworksFactory.getRandomNN();
			if(nnm instanceof StandardNN)
				//nnm.setGentics(2, 0.01f,0.1f, null);
				nnm.setGentics(getRandomTypeOfDataTransformation(), getRandomNumberOfLayers(), getRandomLearningRate(0), getRandomMomentum(0), null);
			else
				//nnm.setGentics(2, 0.01f, 0.1f, 1, 60);
				nnm.setGentics(getRandomTypeOfDataTransformation(), getRandomNumberOfLayers(), getRandomLearningRate(0), getRandomMomentum(0), getRandomRicochetSlopeThreshold(0), getRandomRicochetThreshold(0));
			
			nnm.loadPatternsToNN(patterns);
			return nnm;
		}
		
		
	    @Override
	    public void run() {
	    	if(patterns.size() >= 20){ //if we don't have enough training data we won't train the neural network
	    		for(int i=0; i<Globals.numOfNNInGeneration; i++){	//create the first generation of neural networks
	    			generationOfNN[i] = getRandomNNWithRandomGenetics();
	    		}
	    		
		    	while(true){
		    		Thread NNManager_thread[] = new Thread[Globals.numOfNNInGeneration];
		    		for(int i=0; i<Globals.numOfNNInGeneration; i++){	//Let's train the nets!
		    			NNManager_thread[i] = new Thread(generationOfNN[i]);
		    			NNManager_thread[i].start();
		    			//System.out.println("new NN thread");
		    		}
		    		
		    		for(int i=0; i<Globals.numOfNNInGeneration; i++){	//Check that all the neural networks finish their training 
		    			while(!generationOfNN[i].isEnded()){
		    				double cpuUsage = 0;
		    				OperatingSystemMXBean operatingSystemMXBean = (OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean();
		    				for (Method method : operatingSystemMXBean.getClass().getDeclaredMethods()) {
		    			         method.setAccessible(true);
		    			         String methodName = method.getName();
		    			         if (methodName.startsWith("get") && methodName.contains("Cpu") && methodName.contains("Load") && Modifier.isPublic(method.getModifiers())) {
		    			             Object value;
		    			             try {
		    			                 value = method.invoke(operatingSystemMXBean);
		    			             } catch (Exception e) {
		    			                 value = e;
		    			             }
		    			            // System.out.println(methodName + " = " + value);
		    			             cpuUsage = (double) value;
		    			         }
		    			      }
		    				
		    				if(cpuUsage > Globals.maxAppAllowedCPUUsage){	//We are surpassing the max cpu usage allowed for this app
		    					for(int j=0; j<Globals.numOfNNInGeneration; j++)
		    						generationOfNN[j].slowDown();
		    					
		    				}
		    				else if(cpuUsage < Globals.maxAppAllowedCPUUsage - 0.1f){ //We are allowed to use a 10% more of cpu
		    					for(int j=0; j<Globals.numOfNNInGeneration; j++)
		    						generationOfNN[j].goFaster();
		    					
		    				}
		    				
		    		
		    				try {
								Thread.sleep(100);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
		    			}
		    				//System.out.println("killing NN thread");
		    				NNManager_thread[i].stop();
		    				NNManager_thread[i] = null;		    			
		    		}
		    		
		    		float worstQuality = 101;
		    		int worstQualityIndex = 0;
		    		
		    		
		    		for(int i=0; i<Globals.numOfNNInGeneration-Globals.numOfReproducibleNN; i++){	//Remove the dumbest NN
			    		for(int j=0; j<Globals.numOfNNInGeneration; j++){
			    			if(generationOfNN[j] != null && generationOfNN[j].getBestNN().getNNQuality() < worstQuality){
			    				worstQuality = generationOfNN[j].getBestNN().getNNQuality();
			    				worstQualityIndex = j;
			    			}
			    		}
			    		//System.out.println("removing dumb net of quality="+worstQuality);
			    		worstQuality = 101;
			    		generationOfNN[worstQualityIndex] = null;
		    		}
		    		
		    		for(int i=0; i<Globals.numOfBestNN; i++){	//If current sample is more than a 10% bigger than the bestNN's sample we remove this bestNN because its sample is outdated
		    			if(bestNeuralNetworksEver[i] != null && patterns.size() > bestNeuralNetworksEver[i].getSampleSize()*1.1f){
		    				//System.out.println("current sample too small, removing outdated bestNeuralNetworks");
		    				for(int j=i; j<Globals.numOfBestNN-1; j++)
		    					bestNeuralNetworksEver[j] = bestNeuralNetworksEver[j+1];
		    				bestNeuralNetworksEver[Globals.numOfBestNN-1] = null;
		    			}
		    		}
		    		
		    		for(int i=0; i<Globals.numOfNNInGeneration; i++){
		    			if(generationOfNN[i] != null){	//If this NN is going to reproduce...
		    				for(int j=0; j<Globals.numOfBestNN; j++){	//If this NN is one of the best ever we put it inside bestNeuralNetworksEver 
		    					if(bestNeuralNetworksEver[j] == null ||  generationOfNN[i].getBestNN().getNNQuality() > bestNeuralNetworksEver[j].getNNQuality()){

		    						//if(bestNeuralNetworksEver[j]==null) System.out.println("j:"+j+" és null");
		    						//else System.out.println("else "+generationOfNN[i].getBestNN().getNNQuality()+" "+bestNeuralNetworksEver[j].getNNQuality());
		    						for(int k=j; k<Globals.numOfBestNN-1; k++)
		    							bestNeuralNetworksEver[k+1] = bestNeuralNetworksEver[k];
		    						bestNeuralNetworksEver[j] = generationOfNN[i].getBestNN();
		    						//System.out.println("NEW BEST NN!!!! -> "+j+" "+bestNeuralNetworksEver[j].getNNQuality());
		    						break;
		    					}
		    				}
		    				
		    				
		    				if(generationOfNN[i] instanceof StandardNN){
		    					StandardNN staNN = (StandardNN) NeuralNetworksFactory.getNN(NeuralNetworksFactory.standard);
		    					staNN.loadPatternsToNN(patterns);
		    					StandardNN snn = (StandardNN) generationOfNN[i];
		    					staNN.setLearningRate(getRandomLearningRate(snn.getLearningRate()));
		    					staNN.setMomentum(getRandomMomentum(snn.getMomentum()));
		    					staNN.setNumLayers(snn.getNumberOfLayers());
		    					staNN.setTypeOfDataTransofrmation(snn.getTypeOfDataTransofrmation());
		    					generationOfNN[i] = staNN;
		    				}
		    				else{
		    					RicochetNN ricNN = (RicochetNN) NeuralNetworksFactory.getNN(NeuralNetworksFactory.ricochet);
		    					ricNN.loadPatternsToNN(patterns);
		    					RicochetNN rnn = (RicochetNN) generationOfNN[i];
		    					ricNN.setLearningRate(getRandomLearningRate(rnn.getLearningRate()));
		    					ricNN.setMomentum(getRandomLearningRate(rnn.getMomentum()));
		    					ricNN.setRicochetSlopeThreshold(getRandomLearningRate(rnn.getRicochetSlopeThreshold()));
		    					ricNN.setRicochetThreshold(getRandomLearningRate(rnn.getRicochetThreshold()));
		    					ricNN.setNumLayers(rnn.getNumberOfLayers());
		    					ricNN.setTypeOfDataTransofrmation(rnn.getTypeOfDataTransofrmation());
		    					generationOfNN[i] = ricNN;		    					
		    				}
		    			}
		    			else	//If this NN was not that bright, it won't reproduce...
		    				generationOfNN[i] = getRandomNNWithRandomGenetics();
		    			
		    		}
		    				    		
		    	}
	    	}
	    }
	}
	
	
	
	public void addPattern(RawPattern newPattern){
		patterns.add(newPattern);
	}
	
	public boolean predictPattern(ClientRequest cr){
		float input[] = new float[RawPattern.numAttributes];
		input[0] = cr.getPattern().getAppExecutionTime();
		input[1] = cr.getPattern().getAverageActivityLevel();
		input[2] = cr.getPattern().getAverageDistanceFromScreen();
		input[3] = cr.getPattern().getAverageFaceMovement();
		input[4] = cr.getPattern().getDayOfTheWeek();
		input[5] = cr.getPattern().getDayTime();
		
		
		float predictedAsNegative = 0;
		float predictedAsPossitive = 0;
		
		for (NN nn: ga.bestNeuralNetworksEver){
			if(nn.predict(input)) predictedAsPossitive += (nn.getNNQuality()-50);
			else predictedAsNegative += (nn.getNNQuality()-50);
		}
		
		if(predictedAsPossitive > predictedAsNegative)
			return true;
		else
			return false;
		
	}
}
