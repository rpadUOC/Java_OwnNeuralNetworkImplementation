package Prediction;

import java.util.Random;

import NeuralNetwork.*;

public class NeuralNetworksFactory {
	
	public static int standard = 0, ricochet = 1;;
	
	
	public static NNManager getRandomNN(){
		int num = getRandomNumber(0,1);
		if(num == standard)
			return new StandardNN();
		else
			return new RicochetNN();
	}
	
	public static NNManager getNN(int typeOfNN){
		if(typeOfNN == standard)
			return new StandardNN();
		else
			return new RicochetNN();
		
	}
	
	public static int getRandomNumber(int min, int max){
		Random r = new Random();
		int random = r.nextInt(max-min+1) + min;
		return random;
	}
}
