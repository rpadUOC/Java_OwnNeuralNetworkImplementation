package Data;

import java.io.Serializable;

public class ClientRequest implements Serializable {
	private int request;
	private RawPattern rawPattern;
	
	public int getRequest(){
		return request;
	}
	
	public RawPattern getPattern(){
		return rawPattern;
	}
	
	public ClientRequest(int request, RawPattern rawPattern){
		this.request = request;
		this.rawPattern = rawPattern;
	}

	@Override
	public String toString() {
		return "ClientRequest [request=" + request + ", rawPattern="
				+ rawPattern + "]";
	}
	
	
	
	
}
