package Data;

import java.awt.Point;

public class ActivityData extends Expiration{
	private Point mouse;
	
	public Point getMouse(){
		return mouse;
	}
	
	public ActivityData(Point mouse) {
		super();
		this.mouse = mouse;
	}
	
}
