package Data;

import java.io.Serializable;

public class ServerResponse implements Serializable{
	private int request;
	private int response;
	public ServerResponse(int request, int answer) {
		this.request = request;
		this.response = answer;
	}
	public int getRequest() {
		return request;
	}
	public int getResponse() {
		return response;
	}
	@Override
	public String toString() {
		return "ServerResponse [request=" + request + ", response=" + response
				+ "]";
	}
	
	
	
}
