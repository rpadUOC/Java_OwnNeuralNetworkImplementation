package Data;

import java.io.Serializable;

import source.Globals;

public class RawPattern implements Serializable{
	public static int numAttributes = 6;
	
	private int averageFaceMovement;
	private int averageDistanceFromScreen;
	private int averageActivityLevel;
	private int appExecutionTime;
	private int dayTime;
	private int dayOfTheWeek;
	
	private int EndedWithDistraction = Globals.nothing_to_do;

	
	
	public RawPattern(){
		
	}
	
	public RawPattern(int averageFaceMovement, int averageDistanceFromScreen,
			int averageActivityLevel, int appExecutionTime, int dayTime,
			int dayOfTheWeek, int endedWithDistraction) {
		this.averageFaceMovement = averageFaceMovement;
		this.averageDistanceFromScreen = averageDistanceFromScreen;
		this.averageActivityLevel = averageActivityLevel;
		this.appExecutionTime = appExecutionTime;
		this.dayTime = dayTime;
		this.dayOfTheWeek = dayOfTheWeek;
		EndedWithDistraction = endedWithDistraction;
	}

	public int getAverageFaceMovement() {
		return averageFaceMovement;
	}

	public void setAverageFaceMovement(int averageFaceMovement) {
		this.averageFaceMovement = averageFaceMovement;
	}

	public int getAverageDistanceFromScreen() {
		return averageDistanceFromScreen;
	}

	public void setAverageDistanceFromScreen(int averageDistanceFromScreen) {
		this.averageDistanceFromScreen = averageDistanceFromScreen;
	}

	public int getAverageActivityLevel() {
		return averageActivityLevel;
	}

	public void setAverageActivityLevel(int averageActivityLevel) {
		this.averageActivityLevel = averageActivityLevel;
	}

	public int getAppExecutionTime() {
		return appExecutionTime;
	}

	public void setAppExecutionTime(int appExecutionTime) {
		this.appExecutionTime = appExecutionTime;
	}

	public int getDayTime() {
		return dayTime;
	}

	public void setDayTime(int dayTime) {
		this.dayTime = dayTime;
	}

	public int getDayOfTheWeek() {
		return dayOfTheWeek;
	}

	public void setDayOfTheWeek(int dayOfTheWeek) {
		this.dayOfTheWeek = dayOfTheWeek;
	}

	public int getEndedWithDistraction() {
		return EndedWithDistraction;
	}

	public void setEndedWithDistraction(int endedWithDistraction) {
		EndedWithDistraction = endedWithDistraction;
	}

	@Override
	public String toString() {
		return "RawPattern [averageFaceMovement=" + averageFaceMovement
				+ ", averageDistanceFromScreen=" + averageDistanceFromScreen
				+ ", averageActivityLevel=" + averageActivityLevel
				+ ", appExecutionTime=" + appExecutionTime + ", dayTime="
				+ dayTime + ", dayOfTheWeek=" + dayOfTheWeek
				+ ", EndedWithDistraction=" + EndedWithDistraction + "]";
	}
	
	
	
	
	
}
