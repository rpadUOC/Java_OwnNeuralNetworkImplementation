package Data;


import java.util.ArrayList;

public class ExpirationList {
	private ArrayList<Expiration> list = new ArrayList<Expiration>();
	
	public synchronized void addItem(Expiration e, int secondsToExpire){
		removeExpiredItems();
		e.setExpirationTime(secondsToExpire);
		list.add(e);
	}
	
	public synchronized void removeExpiredItems(){
		for(int i=0; i<list.size(); i++){
			if(list.get(i).isExpired()){
				list.remove(i);
				i--;
			}
		}
	}
	
	public synchronized ArrayList<Expiration> getList(){
		removeExpiredItems();
		return list;
	}
}
