package Data;

import java.awt.Point;

public class WebcamData extends Expiration{
	private int faceSize;
	private Point facePosition;
	
	public int getFaceSize(){
		return faceSize;
	}
	
	public Point getFacePosition(){
		return facePosition;
	}
	
	
	public WebcamData(int faceSize, Point facePosition) {
		super();
		this.faceSize = faceSize;
		this.facePosition = facePosition;
	}
	
	
}
