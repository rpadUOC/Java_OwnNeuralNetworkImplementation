package Data;

import java.sql.Timestamp;

public class Expiration {
	private Timestamp creation;
	private Timestamp expirationTime;
	
	public Expiration(){
		creation = new Timestamp(System.currentTimeMillis());
		expirationTime = new Timestamp(System.currentTimeMillis() + 100*1000);
	}
	
	public Expiration(int seconds){
		creation = new Timestamp(System.currentTimeMillis());
		expirationTime = new Timestamp(System.currentTimeMillis() + seconds*1000);
	}
	
	public Timestamp getCreation(){
		return creation;
	}
	
	public void setExpirationTime(int seconds){
		expirationTime = new Timestamp(System.currentTimeMillis() + seconds*1000);
	}
	
	public boolean isExpired(){
		if(expirationTime.before(new Timestamp(System.currentTimeMillis())))
			return true;
		return false;
	}
	
}
