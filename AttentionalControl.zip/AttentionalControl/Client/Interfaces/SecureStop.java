package Interfaces;

public interface SecureStop {
	public void SecureStop();
}
