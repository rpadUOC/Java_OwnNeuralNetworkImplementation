package GUI;


import Resources.*;



import java.awt.Frame;
import java.awt.Image;


import javax.annotation.Resources;
import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;
import javax.swing.border.EmptyBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Calendar;
import java.util.Date;


import javax.swing.JLabel;

import javax.swing.SwingConstants;
import java.awt.Dimension;




import source.Globals;
import source.Main;
import source.MonitorsManager;
import source.MonitorsManager.DetectFacesThread;
import source.MonitorsManager.NotificationsThread;


import java.awt.Color;
import javax.swing.JSeparator;
import java.awt.Font;
import javax.swing.JSlider;
import javax.swing.JRadioButton;



public class GUI extends JFrame  implements ActionListener, ChangeListener{
	
	private Main main;
	private MonitorsManager monitoring;
	
	private Thread scheduledAlarmThread = null;
	private Thread activityDetectionThread = null;
	private Thread binauralBeatsThread = null;
	private Thread detectWebsitesThread = null;
	private Thread detectFacesThread = null;
	private Thread notificationsThread = null;
	
	private BinauralBeatsThread bbt = null;
	private DetectFacesThread dft_Instance = null;
	private NotificationsThread nt = null;
	
	
	private int tempsAlarma=0;  
	private int llengua = 1;
	private File fileEyes, fileNoEyes; 
	private static boolean webcam = false, llistaActualitzada = false;
	private String actAct = "Enable activity detection", desAct = "Disable activity detection";
	private String actUlls = "Enable eyes detection", desUlls = "Disable eyes detection", waitAMoment = "Wait a moment...";
	private String actNav = "Enable browser detection", desNav = "Disable browser detection";
	private String activarTemps = "Sound alarm after ", segons = " seconds of mouse inactivity";
	private String insensible = "Insensitive", sensible = "Sensitive";
	private String actAl = "Enable alarm", desAl = "Disable alarm";
	private String actOnes = "Play binaural beats", desOnes = "stop binaural beats";
	private String totesWebs = "Detect any website", websEspecifiques = "Detect only websites in the list";
	private String configurarLlista = "Set up websites list";
	private String enNotifications = "Enable notifications", disNotifications = "Disable notifications";

	
	
	
	// GUI 
	private JPanel contentPane;
	private JTextField txtActivity;
	private JLabel lblUlls;
	private JSlider sliderWebcam;
	private JLabel lblWebcamInsensible;
	private JLabel lblWebcamSensible;
	private JButton btnFace;
	private JButton btnDesactivat;
	private JButton btnWeb;
	private JLabel lblActivarAlarmaDesprs;
	private JLabel lblSegonsDinactivitat;
	private JSpinner spinner;
	private JButton btAlarma;
	private JButton btnOnesBinaurals;
	private SpinnerDateModel modelModificat;
	private JButton btnConfiguraLlista;
	private JRadioButton radioEspecifiques, radioTot;
	private ButtonGroup group;
	private JSlider sliderNotifications;
	private JButton btnEnableNotifications;
	private JLabel lblNotificationsInsensible;
	private JLabel lblNotificationsSensible;
	
	
	///////////////////////////////////
	
	public int getNotificationsSensibilityTime(){
		return (30 + (100-sliderNotifications.getValue()) * 10); //Time returned in milliseconds
	}
	
	
	public GUI(Main refMain, MonitorsManager monitor){
	
		main = refMain;
		monitoring = monitor;
		
		
		Image im = null;
	    try {
	    	//System.out.println(getClass().getResourceAsStream(Globals.app_icon));
	    	im = ImageIO.read(getClass().getResource(Globals.app_icon));
	    } catch (IOException ex) {
	     
	    }
	    setIconImage(im);
		
		Frame[] frames = getFrames();
	    for(Frame f: frames){
	        f.addWindowListener(new WindowAdapter() {
	            @SuppressWarnings("deprecation")
				public void windowClosing(WindowEvent e) {
	                if(dft_Instance != null){
	                	dft_Instance.SecureStop();
	                	detectFacesThread.stop();
	                }
	            }

	        });
	    }
	
    
		fileEyes = new File(""+Globals.eyes_icon);
		fileNoEyes = new File(""+Globals.noeyes_icon);
		
		
		
		
		setForeground(Color.BLUE);
		setResizable(false);
		setTitle("Attentional control");
		setPreferredSize(new Dimension(200, 100));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 426, 545);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		//notifications
		btnEnableNotifications = new JButton(enNotifications);
		sliderNotifications = new JSlider();
		sliderNotifications.addChangeListener(new SliderListener());
		btnEnableNotifications.setBounds(70, 57, 270, 23);
		btnEnableNotifications.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JButton b=(JButton)arg0.getSource();
				if(b.getText().equals(enNotifications)){
					int dialogResult = JOptionPane.showConfirmDialog (null, "If you enable notifications, an artificial intelligence(AI) will show you notifications adverting \nyou to stay focused when this AI thinks you may be a bit distracted. \nEnabling notifications also means that you agree with sending anonymous data which will \nhelp to improve this AI.","Do you want to enable notifications?", JOptionPane.YES_NO_OPTION);
					if(dialogResult == JOptionPane.YES_OPTION){
						sliderNotifications.setVisible(true);
						lblNotificationsInsensible.setVisible(true);
						lblNotificationsSensible.setVisible(true);
						b.setText(disNotifications);
						notificationsThread = new Thread(monitoring.getNotificationsThreadInstance());
						notificationsThread.start(); 
					}					
				}
				else{
					sliderNotifications.setVisible(false);
					lblNotificationsInsensible.setVisible(false);
					lblNotificationsSensible.setVisible(false);
					b.setText(enNotifications);
					if(nt != null)
						nt.SecureStop();
				} 
			} 
		});
		contentPane.add(btnEnableNotifications);
		sliderNotifications.setBounds(115, 20, 177, 23);
		sliderNotifications.setName("sliderNotificacions");
		contentPane.add(sliderNotifications);
		
		lblNotificationsInsensible = new JLabel(insensible);
		lblNotificationsSensible = new JLabel(sensible);
		
		lblNotificationsInsensible.setBounds(55, 23, 64, 14);
		contentPane.add(lblNotificationsInsensible);		
		lblNotificationsSensible.setBounds(300, 23, 52, 14);
		contentPane.add(lblNotificationsSensible);
		
		
		sliderNotifications.setVisible(false);
		lblNotificationsInsensible.setVisible(false);
		lblNotificationsSensible.setVisible(false);
		setNotificationsTime(sliderNotifications.getValue());
		
		JSeparator separator_16 = new JSeparator();
		separator_16.setBounds(43, 15, 318, 2);
		contentPane.add(separator_16);
		
		JSeparator separator_17 = new JSeparator();
		separator_17.setOrientation(SwingConstants.VERTICAL);
		separator_17.setBounds(43, 15, 17, 67);
		contentPane.add(separator_17);
		
		JSeparator separator_18 = new JSeparator();
		separator_18.setBounds(43, 83, 318, 2);
		contentPane.add(separator_18);
		
		JSeparator separator_19 = new JSeparator();
		separator_19.setOrientation(SwingConstants.VERTICAL);
		separator_19.setBounds(360, 15, 17, 67);
		contentPane.add(separator_19);
		
		///////////
		
		
				
		//activitat
		txtActivity = new JTextField(); 
		txtActivity.setText("40");
		txtActivity.setHorizontalAlignment(SwingConstants.CENTER);
		txtActivity.setBounds(159, 104, 68, 20);
		contentPane.add(txtActivity);
		txtActivity.setColumns(10); 

		lblActivarAlarmaDesprs = new JLabel(activarTemps);
		lblActivarAlarmaDesprs.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblActivarAlarmaDesprs.setHorizontalAlignment(SwingConstants.RIGHT);
		lblActivarAlarmaDesprs.setBounds(0, 107, 156, 14);
		contentPane.add(lblActivarAlarmaDesprs);
		
		lblSegonsDinactivitat = new JLabel(segons);
		lblSegonsDinactivitat.setFont(new Font("Tahoma", Font.PLAIN, 10));
		lblSegonsDinactivitat.setBounds(231, 107, 129, 14);
		contentPane.add(lblSegonsDinactivitat);
		
		btnDesactivat = new JButton(actAct);
		btnDesactivat.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JButton b=(JButton)arg0.getSource();
				if(b.getText().equals(actAct)){
					monitoring.setAlarmTime(Integer.parseInt(txtActivity.getText()));
					activityDetectionThread = new Thread(monitoring.getActivityDetectionThreadInstance());
					activityDetectionThread.start();
					b.setText(desAct);
				}
				else{
					activityDetectionThread.stop();
					b.setText(actAct);
				} 
			} 
		});
		btnDesactivat.setBounds(70, 135, 270, 23);
		contentPane.add(btnDesactivat);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(43, 94, 318, 2);
		contentPane.add(separator);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(43, 94, 17, 67);
		contentPane.add(separator_1);
		
		JSeparator separator_2 = new JSeparator();
		separator_2.setBounds(43, 161, 318, 2);
		contentPane.add(separator_2);
		
		JSeparator separator_3 = new JSeparator();
		separator_3.setOrientation(SwingConstants.VERTICAL);
		separator_3.setBounds(360, 94, 1, 67);
		contentPane.add(separator_3);
		
		////////
		
		//webcam
		lblUlls = new JLabel("");
		sliderWebcam = new JSlider();
		lblWebcamInsensible = new JLabel(insensible);
		lblWebcamSensible = new JLabel(sensible);
		
		lblWebcamInsensible.setVisible(false);
		lblWebcamSensible.setVisible(false);
		sliderWebcam.setVisible(false);
		btnFace = new JButton(actUlls);
		btnFace.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JButton b=(JButton)arg0.getSource();
				if(b.getText().equals(actUlls)){
					dft_Instance = monitoring.getDetectFacesThreadInstance();
					detectFacesThread = new Thread(dft_Instance);
					detectFacesThread.start();
					
					b.setText(desUlls);
					BufferedImage img;
					try {
						img = ImageIO.read(fileNoEyes); 
						lblUlls.setIcon(new ImageIcon(img));
						lblWebcamInsensible.setVisible(true);
						lblWebcamSensible.setVisible(true);
						sliderWebcam.setVisible(true);
						lblUlls.setVisible(true);
						
					} catch (IOException e) { 
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				else{  
					dft_Instance.SecureStop();
					detectFacesThread.stop(); 
					b.setText(actUlls);
					lblUlls.setIcon(null);
					lblWebcamInsensible.setVisible(false);
					lblWebcamSensible.setVisible(false);
					sliderWebcam.setVisible(false);
					lblUlls.setVisible(false);
				} 
			} 
		});
		btnFace.setBounds(70, 225, 270, 23);
		contentPane.add(btnFace);
		
		sliderWebcam.setBounds(115, 175, 177, 23);
		sliderWebcam.addChangeListener(new SliderListener());
		sliderWebcam.setName("sliderWebcam");
		 
		
		contentPane.add(sliderWebcam);
		
		lblUlls.setBounds(184, 200, 38, 20);
		
		
		contentPane.add(lblUlls);
		 
		
		lblWebcamInsensible.setBounds(55, 178, 64, 14);
		contentPane.add(lblWebcamInsensible);
		
		
		lblWebcamSensible.setBounds(300, 178, 52, 14);
		contentPane.add(lblWebcamSensible);
		
		JSeparator separator_4 = new JSeparator();
		separator_4.setBounds(43, 172, 318, 2);
		contentPane.add(separator_4);
		
		JSeparator separator_5 = new JSeparator();
		separator_5.setOrientation(SwingConstants.VERTICAL);
		separator_5.setBounds(43, 172, 17, 80);
		contentPane.add(separator_5);
		
		JSeparator separator_6 = new JSeparator();
		separator_6.setOrientation(SwingConstants.VERTICAL);
		separator_6.setBounds(360, 172, 1, 80);
		contentPane.add(separator_6);
		
		JSeparator separator_7 = new JSeparator();
		separator_7.setBounds(43, 250, 318, 2);
		contentPane.add(separator_7);
		
		
		/////////
		
		
		//web
		btnWeb = new JButton(actNav);
		btnWeb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JButton b=(JButton)arg0.getSource();
				if(b.getText().equals(actNav)){
					detectWebsitesThread = new Thread(monitoring.getDetectWebsitesThreadInstance());
					detectWebsitesThread.start(); 
					radioEspecifiques.setVisible(true);
					radioTot.setVisible(true);
					btnConfiguraLlista.setVisible(true);
					b.setText(desNav);
				}
				else{  
					detectWebsitesThread.stop(); 
					radioEspecifiques.setVisible(false);
					radioTot.setVisible(false);
					btnConfiguraLlista.setVisible(false);
					b.setText(actNav);
				} 
			}  
		}); 
		btnWeb.setBounds(70, 350, 270, 23);
		contentPane.add(btnWeb);
		
		
		
		radioTot = new JRadioButton(totesWebs);
		radioTot.setBounds(70, 270, 270, 23);
		radioTot.setVisible(false);
		contentPane.add(radioTot);
		
		radioEspecifiques = new JRadioButton(websEspecifiques);
		radioEspecifiques.setBounds(70, 292, 270, 23);
		radioEspecifiques.setSelected(true);
		radioEspecifiques.setVisible(false);
		
		group = new ButtonGroup();
		group.add(radioEspecifiques);
		group.add(radioTot);
		contentPane.add(radioEspecifiques);
		
		btnConfiguraLlista = new JButton(configurarLlista);
		btnConfiguraLlista.setBounds(70, 316, 270, 23);
		btnConfiguraLlista.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ProhibitedWebsitesGUI llw = new ProhibitedWebsitesGUI(main, monitoring);
				llw.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
				llw.setVisible(true); 
				llw.show();
			}
		});
		btnConfiguraLlista.setVisible(false);
		contentPane.add(btnConfiguraLlista);
		
		JSeparator separator_12 = new JSeparator();
		separator_12.setBounds(43, 263, 318, 92);
		contentPane.add(separator_12);
		
		JSeparator separator_13 = new JSeparator();
		separator_13.setOrientation(SwingConstants.VERTICAL);
		separator_13.setBounds(43, 263, 17, 115);
		contentPane.add(separator_13);
		
		JSeparator separator_14 = new JSeparator();
		separator_14.setBounds(43, 377, 318, 2);
		contentPane.add(separator_14);
		
		JSeparator separator_15 = new JSeparator();
		separator_15.setOrientation(SwingConstants.VERTICAL);
		separator_15.setBounds(360, 263, 1, 115);
		contentPane.add(separator_15);
		
		///////////////////////////
		
		
		
		
		//alarma
		JSeparator separator_8 = new JSeparator();
		separator_8.setBounds(43, 389, 318, 2);
		contentPane.add(separator_8);
		
		JSeparator separator_9 = new JSeparator();
		separator_9.setOrientation(SwingConstants.VERTICAL);
		separator_9.setBounds(43, 389, 17, 110);
		contentPane.add(separator_9);
		
		JSeparator separator_10 = new JSeparator();
		separator_10.setOrientation(SwingConstants.VERTICAL);
		separator_10.setBounds(360, 389, 1, 110);
		contentPane.add(separator_10);
		
		JSeparator separator_11 = new JSeparator();
		separator_11.setBounds(43, 499, 318, 2);
		contentPane.add(separator_11);
		
		btAlarma = new JButton(actAl);
		btAlarma.setBounds(70, 426, 270, 23);
		btAlarma.addActionListener(this);
		
		
		contentPane.add(btAlarma);
		
		Date date = new Date();
		if(date.getMinutes() < 50) date.setMinutes(date.getMinutes()+10);
		else date.setHours(date.getHours()+1);
		SpinnerDateModel monthModel = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
		spinner = new JSpinner(monthModel);
		
		JSpinner .DateEditor de = new JSpinner.DateEditor(spinner, "HH:mm");
		spinner.setEditor(de);
		spinner.addChangeListener(this);
		spinner.setBounds(181, 397, 60, 23);
		spinner.setVisible(false);
		contentPane.add(spinner);
		
		////////////
		
		btnOnesBinaurals = new JButton(actOnes);
		btnOnesBinaurals.setBounds(70, 466, 270, 23);
		btnOnesBinaurals.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				JButton b=(JButton)arg0.getSource();
				if(b.getText().equals(actOnes)){
					bbt = new BinauralBeatsThread();
					binauralBeatsThread=new Thread(bbt);
					binauralBeatsThread.start(); 
					b.setText(desOnes);
				}
				else{
					bbt.atura();
					binauralBeatsThread.stop();
					b.setText(actOnes);
				}
			}
		});
		
		
		contentPane.add(btnOnesBinaurals);
		
		
		
	}

	
	class SliderListener implements ChangeListener {
	    public void stateChanged(ChangeEvent e) {
	        JSlider source = (JSlider)e.getSource();
	        if (!source.getValueIsAdjusting()) {
	        	if(source.getName().equals("sliderWebcam"))
	        		monitoring.setSensibility(100 - (int)source.getValue());
	        	else
	        		setNotificationsTime((int) source.getValue());
	        }    
	    }
	}
	
	@Override
	public void stateChanged(ChangeEvent e) {
		Date date = new Date();
		
		modelModificat = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
		modelModificat.setValue(spinner.getModel().getValue());
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof JButton)
		{
			JButton b=(JButton)e.getSource();
			if(b.getText().equals(actAl)){
				scheduledAlarmThread = new Thread(monitoring.getScheduledAlarmThreadInstance());
				scheduledAlarmThread.start(); 
				b.setText(desAl);
				Date date = new Date();
				if(date.getMinutes() < 50) date.setMinutes(date.getMinutes()+10);
				else date.setHours(date.getHours()+1);
				SpinnerDateModel monthModel = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
				spinner.setModel(monthModel);
				JSpinner .DateEditor de = new JSpinner.DateEditor(spinner, "HH:mm");
				spinner.setEditor(de);
				spinner.setVisible(true);
			}
			else{  
				scheduledAlarmThread.stop(); 
				b.setText(actAl);
				spinner.setVisible(false);
			} 
		}
	}
	
	public void setNotificationsTime(int time){
		monitoring.setNotificationsTime(300 + (int)(time*33) );
	}
	
	public SpinnerDateModel getModelModificat(){
		return modelModificat;
	}
	
	public JTextField getTextActivity(){
		return txtActivity;
	}
	
	public JRadioButton getRadioEspecifiques(){
		return radioEspecifiques;
	}
	
	public void setBtnFace(String text){
		btnFace.setText(text);
	}
	
	public void setDesUlls(){
		btnFace.setEnabled(true);
		btnFace.setText(desUlls);
	}
	
	public void setWaitAMoment(){
		btnFace.setText(waitAMoment);
		btnFace.setEnabled(false);
	}
	
	
	public void setEyesFoundImage(boolean found){
		BufferedImage img;
		try {
			if(found)
				img = ImageIO.read(fileEyes);
			else
				img = ImageIO.read(fileNoEyes);
			lblUlls.setIcon(new ImageIcon(img));
		} catch (IOException e) { 
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void setEyesImageEnabled(boolean enabled){
		lblUlls.setVisible(false);
		if(enabled)
			lblUlls.enable();
		else
			lblUlls.disable();
		lblUlls.setVisible(true);
	}
	
	public class BinauralBeatsThread implements Runnable {
		Clip clip = null;   
		boolean continua;
	    public void run() {
	    	continua = true;
	    	while(true){
				try { 
					clip = AudioSystem.getClip();
					InputStream audioSrc = getClass().getResourceAsStream(Globals.waves_sound);
					InputStream bufferedIn = new BufferedInputStream(audioSrc);
					AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);

    		        clip.open(audioStream);   
    		        clip.start(); 
    		        if(!continua) clip.stop();
    		        try {
						if(!continua) clip.stop();
						Thread.sleep(4000);
						
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
    		          
				} catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
					// TODO Auto-generated catch block
					//JOptionPane.showMessageDialog(null, "My Goodness, this is so concise");
					e.printStackTrace();
				}
	    	} 
	    }
	    public void atura(){
	    	continua = false;
	    }
	}
	
}
