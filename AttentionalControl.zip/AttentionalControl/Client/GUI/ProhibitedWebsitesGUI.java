package GUI;

import javax.swing.JDialog;
import javax.swing.JTextArea;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;

import source.Globals;
import source.Main;
import source.MonitorsManager;

public class ProhibitedWebsitesGUI extends JDialog {
	
	private MonitorsManager monitoring;
	
	
	private Main main;
	private JTextArea textArea;
	
	public ProhibitedWebsitesGUI(Main main, MonitorsManager monitor){
		this.main = main;
		monitoring = monitor;
		monitoring.setPause(true);
		
		
		addWindowListener(new WindowAdapter() 
		{
			  public void windowClosed(WindowEvent e)
			  {
			    monitoring.setPause(false);
			  }
		});
	    
	    
		getContentPane().setLayout(null);
		setBounds(100, 100, 440, 304);
		setResizable(false);
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(0, 0, 435, 220);
		
		
		textArea = new JTextArea();
		scrollPane.setViewportView(textArea);
		getContentPane().add(scrollPane);

		
		
		 BufferedReader br;
			try {
				br = new BufferedReader(new FileReader(Globals.list_txt));
				 try {
				        StringBuilder sb = new StringBuilder();
				        String line = null;
						line = br.readLine();
					
				        while (line != null) 
				        {
				            sb.append(line);
				            sb.append(System.lineSeparator());
							line = br.readLine();
				        }
				        textArea.setText(sb.toString());
				    } finally {
							br.close();
						
				    }
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
			    
			
			JButton btnNewButton;
				btnNewButton = new JButton("Save list");
			btnNewButton.setBounds(315, 234, 109, 23);
			btnNewButton.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent arg0) {
					PrintWriter writer;
					try {
						writer = new PrintWriter(Globals.list_txt, "UTF-8");
						writer.print(textArea.getText());
						writer.close();
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					}
					monitoring.setUpdatedList();
					dispose();
				} 
			});
			getContentPane().add(btnNewButton); 
				
	}
}

