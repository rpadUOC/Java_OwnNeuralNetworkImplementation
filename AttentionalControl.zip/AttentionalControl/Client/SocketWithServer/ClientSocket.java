package SocketWithServer;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

import Data.ClientRequest;
import Data.RawPattern;
import Data.ServerResponse;

import source.Globals;


public class ClientSocket implements Runnable{

	private String host = "localhost";
	private Socket socket = null;
	private ObjectInputStream in = null;
	private ObjectOutputStream out = null;
	private boolean keepConnection = true, keepWorking = true;
	private int socketFails = 0;
	
	private int patternRequestedByServer = Globals.nothing_to_do;
	private boolean timeToSend = false;
	private boolean notificationActivated = false;
	
	private Object lock_pattern = new Object();
	private Object lock_patternReqSer = new Object();
	private Object lock_notification = new Object();
	private RawPattern patternToSend = null;
	
	
	public boolean isNotificationActivated(){
		synchronized(lock_notification){
			if(notificationActivated){
				notificationActivated = false;
				return true;
			}
			else return false;
		}
	}
	
	public void sendPattern(RawPattern rp){
		synchronized(lock_pattern){
			//System.out.println("preparing patern to send");
			patternToSend = rp;
			timeToSend = true;
		}
	}
	
	public void predict(RawPattern rp){
		synchronized(lock_pattern){
			//System.out.println("calling predict(RawPattern rp) method!!");
			patternToSend = rp;
			timeToSend = true;
		}
	}
	
	
	public void setKeepWorking(boolean keepWorking) {
		this.keepWorking = keepWorking;
	}

	@Override
	public void run() {
		while(keepWorking)
		{
			try {
				socket = new Socket(Globals.Server_Host, Globals.Server_Port);
				out = new ObjectOutputStream(socket.getOutputStream());
			    in = new ObjectInputStream(socket.getInputStream());
			    
			    int count = 0;
			     while(keepConnection && keepWorking)
			     { 
			    	 try{
			    		 int patRequested = getPatternRequestedByServer();
			    		
			    		 if(isTimeToSend()){
			    			 synchronized(lock_pattern){
				    			 if(patternToSend != null && patternToSend.getEndedWithDistraction() == patRequested){ //send pattern to learn
				    				 //System.out.println("try to send pattern to learn");
				    				 out.writeObject(new ClientRequest(Globals.request_i_send_new_training_pattern, patternToSend));
				    				 //System.out.println("client- we send new pattern to learn");
				    				 ServerResponse obj = (ServerResponse) in.readObject();
				    				 patternToSend = null;
				    				 setPatternRequestedByServer(Globals.nothing_to_do); //We'll ask the server later again
				    				 timeToSend = false;
				    				 try {
										Thread.sleep(60000);
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
				    			 }
				    			 else if(patternToSend != null && patternToSend.getEndedWithDistraction() == Globals.nothing_to_do){ //request prediction
				    				 out.writeObject(new ClientRequest(Globals.request_prediction, patternToSend));
				    				 //System.out.println("client- we request prediction");
				    				 ServerResponse obj = (ServerResponse) in.readObject();
				    				 //System.out.println("client- prediction received "+obj.getResponse()+" "+obj);
				    				 synchronized(lock_notification){
				    					 if(obj.getResponse() == Globals.positive)
				    						 notificationActivated = true;
				    					 else
				    						 notificationActivated = false;
				    				 }
				    				 patternToSend = null;
				    				 timeToSend = false;
				    			 }
				    			
			    			 }
			    		 }
			    		 else if(patRequested == Globals.nothing_to_do && count >= 30){ 
		    				 count = 0;
		    				 out.writeObject(new ClientRequest(Globals.request_what_training_patterns_do_you_need, null)); //what pattern do you need?
		    				 //System.out.println("client- what pattern do u need?");
		    				 ServerResponse obj = (ServerResponse) in.readObject();
		    				 //System.out.println("received "+obj.getResponse());
		    				 setPatternRequestedByServer(obj.getResponse());
		    			 }
			    		 else{
			    			 try {
								Thread.sleep(100);
								//System.out.println("wait "+count);
								count++;
							} catch (InterruptedException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
			    		 }

					     if(socketFails != 0) 
				    			socketFails = 0;
			    	 } catch ( IOException | ClassNotFoundException e) { 
			    		 socketFails++;
				    	 if(socketFails >= 10) 
				    			keepConnection = false;	//CONNECTION IS LOST
			 		}   
			     } 
			} catch ( IOException e) {
				e.printStackTrace();
			} 
		}

	    //CLOSE
	    try {
	    	socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    
	    System.out.println("END OF THREAD (ClientSocket)");
	}
	
	
	public synchronized int getPatternRequestedByServer(){
		synchronized(lock_patternReqSer){
			return patternRequestedByServer;
		}
	}
	
	public synchronized void setPatternRequestedByServer(int pattern){
		synchronized(lock_patternReqSer){
			patternRequestedByServer = pattern;
		}
	}
	
	public boolean isTimeToSend(){
		return timeToSend;
	}

}
