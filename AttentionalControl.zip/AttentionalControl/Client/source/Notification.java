package source;

import java.awt.AWTException;
import java.awt.Image;
import java.awt.SystemTray;
import java.awt.Toolkit;
import java.awt.TrayIcon;
import java.awt.TrayIcon.MessageType;

public class Notification {
	private String[] messagesToShow = {"Hi, stay focused! You can do it!", "Do not get distracted!", "Stay focused, concentration is the basis of productivity",
										"The way to get started is to quit talking and begin doing", "Infinite striving to be the best is man’s duty",
										"Focus on being productive instead of busy", "There is no substitute for hard work", "Lost time is never found again"};
	
	public Notification(){
		SystemTray tray = SystemTray.getSystemTray();
        Image image = Toolkit.getDefaultToolkit().createImage("ic_launcher.png");
        TrayIcon trayIcon = new TrayIcon(image, "Tray Demo");
        trayIcon.setImageAutoSize(true);
        trayIcon.setToolTip("System tray icon demo");
        try {
			tray.add(trayIcon);
		} catch (AWTException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        trayIcon.displayMessage(messagesToShow[(int )(Math.random() * messagesToShow.length)], "Attentional Control Notification", MessageType.WARNING);
	}
}
