package source;

public class Listener {
	private int numListeners = 0;

	protected void addListener() {
		numListeners++;
	}


	protected boolean removeListener() {
		numListeners--;
		if(numListeners < 1)
			return false;
		return true;
	}
}
