package source;

import java.awt.MouseInfo;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.SpinnerDateModel;

import org.opencv.core.Scalar;
import org.opencv.core.Core;
import org.opencv.core.CvType;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Point;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.highgui.Highgui;
import org.opencv.highgui.VideoCapture;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

import Data.ActivityData;
import Data.Expiration;
import Data.ExpirationList;
import Data.WebcamData;
import GUI.GUI;
import source.MonitorsManager.DetectFacesThread;

public class Monitors {
	private Thread mat = null;
	private Thread mwt = null;
	private Thread mwct = null;
	private MonitorActivityThread mat_class;
	private MonitorWebsThread mwt_class;
	private MonitorWebcamThread mwct_class;
	private Timestamp startTime;
	
	public Monitors(){
		startTime = new Timestamp(System.currentTimeMillis());
	}

	
	public int getDayOfWeek(){
		Date date = new Date();  
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date); 
		return calendar.get(Calendar.DAY_OF_WEEK);
	}
	
	public int getHourOfDay(){
		Date date = new Date();  
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date); 
		return calendar.get(Calendar.HOUR_OF_DAY);
	}
	
	public int getSoftwareExecutionTime(){
		Timestamp time = new Timestamp(System.currentTimeMillis());
		return (int)((time.getTime() - startTime.getTime())/1000);
	}
	
	
	
	public void setUpdatedList(){
		if(mwt != null)
			mwt_class.setUpdatedList();
	}
	
	public void setSensibility(int sensibility){
		if(mwct != null)
			mwct_class.setSensibility(sensibility);
	}
	
	public MonitorWebcamThread listenWebcamMonitor(DetectFacesThread detectFaceThread, boolean webcamNeverStarted){
		if(mwct == null){
			mwct_class = new MonitorWebcamThread(webcamNeverStarted);
			mwct = new Thread(mwct_class);
			mwct.start();
		}
		if(detectFaceThread != null)
			mwct_class.setDetectFaceThreadInstance(detectFaceThread);
		return mwct_class;
	} 
	
	public void ignoreWebcamMonitor(DetectFacesThread detectFaceThread){
		if(mwct != null){
			if(detectFaceThread != null) 
				mwct_class.destroyDetectFaceThreadInstance();
			if(!mwct_class.removeListener()){
				mwct_class.stopWebcam();
				mwct.stop();
				mwct_class = null;
				mwct = null;
			}
		}
	}
	
	
	public MonitorWebsThread listenWebsMonitor(){
		if(mwt == null){
			mwt_class = new MonitorWebsThread();
			mwt = new Thread(mwt_class);
			mwt.start();
		}
		return mwt_class;
	} 
	
	public void ignoreWebsMonitor(){
		if(mwt != null && !mwt_class.removeListener()){
			mwt.stop();
			mwt_class = null;
			mwt = null;
		}
	}
	
	
	public MonitorActivityThread listenActivityMonitor(){
		if(mat == null){
			mat_class = new MonitorActivityThread();
			mat = new Thread(mat_class);
			mat.start();
		}
		return mat_class;
	} 
	
	public void ignoreActivityMonitor(){
		if(mat != null && !mat_class.removeListener()){
			mat.stop();
			mat_class = null;
			mat = null;
		}
	}
	
	
	
	public class MonitorWebcamThread extends Listener implements Runnable {
		boolean webcam = false;
		boolean webcamNeverStarted = true;
		DetectFacesThread detectFaceThread = null;
		int sensibility = 50;
		
		int withoutFace;
		VideoCapture capture;
		
		private Object lock_sensibility = new Object();
		ExpirationList eList = new ExpirationList();
		private Object lock_list = new Object();
		
		
		public ArrayList<Expiration> getNonExpiredList(){
			synchronized(lock_list){
				return eList.getList();
			}
		}
		
		public MonitorWebcamThread(boolean webcamNeverStarted){
			this.webcamNeverStarted = webcamNeverStarted;
		}
		
		public void setDetectFaceThreadInstance(DetectFacesThread detectFaceThread){
			this.detectFaceThread = detectFaceThread;
		}
		
		@Override
		public void run() {
			
				withoutFace = 0;
	         
				System.loadLibrary(Core.NATIVE_LIBRARY_NAME);

		        String face_cascade_name = ""+Globals.haarcascade_face;
		        String eyes_cascade_name = ""+Globals.haarcascade_eye;
		        CascadeClassifier face_cascade = new CascadeClassifier();
		        CascadeClassifier eyes_cascade = new CascadeClassifier(); 
		        //System.out.println("capture through camera " + Core.VERSION);

		          
		        if(!face_cascade.load(face_cascade_name))
		        	JOptionPane.showMessageDialog(null,face_cascade_name+" not found!");
		        else
		            System.out.println("Success loading face cascade");


		        if(!eyes_cascade.load(eyes_cascade_name))
		        	JOptionPane.showMessageDialog(null,face_cascade_name+" not found!");
		        else
		            System.out.println("Success loading eyes cascade");

		        capture = new VideoCapture(0);

		        if(!capture.isOpened())
		        	JOptionPane.showMessageDialog(null,"Webcam not found");
		        else
		            System.out.println("Conected to camera: "+capture.toString());
		        
		        
		        Mat frame = new Mat();
		        while(true)
		        {
		    		try {
						Thread.sleep(3000);
						withoutFace++;
						//System.out.println("withoutface "+withoutFace);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

	        	 	capture.retrieve(frame);
	        	 	if(!webcam){
	        	 		if(detectFaceThread != null) detectFaceThread.startingWebcam();
						if(webcamNeverStarted){
							try {
								Thread.sleep(45000); 
							} catch (InterruptedException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
								 
							} 
						}
						//System.out.println("aft 45 "+capture.isOpened());
						if(detectFaceThread != null) detectFaceThread.stopingWebcam();
							
							
						webcam = true;
						run(); 
				    }

				    Mat frame_gray = new Mat();
				    Imgproc.cvtColor(frame, frame_gray, Imgproc.COLOR_BGRA2GRAY);
				    Imgproc.equalizeHist(frame_gray, frame_gray);


				    MatOfRect faces = new MatOfRect();

				    face_cascade.detectMultiScale(frame_gray, faces, 1.1, 2, 0, new Size(sensibility,sensibility), new Size(300,300) );
				 
 
				    Rect[] facesArray = faces.toArray(); 
				    //System.out.println("array "+facesArray.length);
			        //JOptionPane.showMessageDialog(null,"num:"+facesArray.length);
			        if(detectFaceThread != null && withoutFace >= 20) detectFaceThread.communicateWithoutFace(withoutFace);
			        
			        if(facesArray.length == 0 && withoutFace>1){
			        	if(detectFaceThread != null) detectFaceThread.setEyesFoundImage(false);
			        }
			        for(int i=0; i<facesArray.length; i++) 
			        {
			        	//if(facesArray[i] == null) break;
			        	//System.out.println("cara mides width, height "+facesArray[i].width+" "+facesArray[i].height);
			            Point center = new Point(facesArray[i].x + facesArray[i].width * 0.5, facesArray[i].y + facesArray[i].height * 0.5);
			            Core.ellipse(frame, center, new Size(facesArray[i].width * 0.5, facesArray[i].height * 0.5), 0, 0, 360, new Scalar(255, 0, 255), 4, 8, 0);

			             Mat faceROI = frame_gray.submat(facesArray[i]); 
			             MatOfRect eyes = new MatOfRect();
	 
			             eyes_cascade.detectMultiScale(faceROI, eyes, 1.1, 2, 0,new Size(sensibility,sensibility), new Size(200,200));            

			             Rect[] eyesArray = eyes.toArray(); 
			             if(eyesArray.length>0){
			            	 withoutFace = 0;
			            	 if(detectFaceThread != null) detectFaceThread.setEyesFoundImage(true);
			             }
			             else if(withoutFace>15){
			            	 if(detectFaceThread != null) detectFaceThread.setEyesFoundImage(false);
			             }
			             for (int j = 0; j < eyesArray.length; j++)
			             {
			            	 if(j == 1) break;
			                Point center1 = new Point(facesArray[i].x + eyesArray[j].x + eyesArray[j].width * 0.5, facesArray[i].y + eyesArray[j].y + eyesArray[j].height * 0.5);
			                //int radius = (int) Math.round((eyesArray[j].width + eyesArray[j].height) * 0.25);
			                //Core.circle(frame, center1, radius, new Scalar(255, 0, 0), 4, 8, 0);
			                //System.out.println("trobatt "+center1+" "+facesArray[i].width+" "+facesArray[i].height);
			                //Highgui.imwrite("frame.jpg", frame); 

			                java.awt.Point p = new java.awt.Point();
			                p.x = (int) center1.x;
			                p.y = (int) center1.y;
			                synchronized(lock_list){
			                	eList.addItem(new WebcamData(facesArray[i].width, p), 60);
			                }
			             }
			        } 
		        } 
		        //Imgproc.imwrite(window_name, frame);
			    
		}
		
		public void destroyDetectFaceThreadInstance(){
			//System.out.println("destroyDetectFaceThreadInstance");
			detectFaceThread = null;
		}
		
		public void setSensibility(int sensibility){
			synchronized(lock_sensibility){
				this.sensibility = sensibility;
			}
		}
		
		public void stopWebcam(){
			//System.out.println("stop webcam");
			capture.release();
		}
	}
	
	
	public class MonitorWebsThread extends Listener implements Runnable {
		List<String> llista;
		boolean listUpdated = false;
		boolean browserUsed = false;
		boolean prohibitedWebsitesVisited = false;
		private Object lock_detections = new Object();
		private Object lock_listUpdated = new Object();
		
		public void setUpdatedList(){
			synchronized(lock_listUpdated){
				listUpdated = true;
			}
		}
		
		public boolean getBrowserUsed(){
			synchronized(lock_detections){
				return browserUsed;
			}
		}
		
		public boolean getProhibitedWebsitesVisited(){
			synchronized(lock_detections){
				return prohibitedWebsitesVisited;
			}
		}
		
		public void carregaLlista(){
			llista = new ArrayList<String>();
			 BufferedReader br;
		 		try {
		 			br = new BufferedReader(new FileReader(Globals.list_txt));
		 			 try {
		 			        String line = null;
		 					line = br.readLine();
		 				
		 			        while (line != null) 
		 			        {
		 			            llista.add(line);
		 			           //System.out.println("afegint lliista "+line);
		 						line = br.readLine();
		 			        }
		 			    } finally {
		 						br.close();
		 					
		 			    }
		 		} catch (IOException e) {
		 			// TODO Auto-generated catch block
		 			e.printStackTrace();
		 		}
			}
		    public void run() {
		    	llista = new ArrayList<String>();
		    	carregaLlista();
		    	while(true){
		    		if(listUpdated)
		    		{
		    			synchronized(lock_listUpdated){
		    				listUpdated = false;
		    			}
		    			carregaLlista();
		    		}
		    		
		    		//find web browser
		    		try {
						Thread.sleep(4000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
		    		Process p = null;
					try {
						p = Runtime.getRuntime().exec("tasklist");
					} catch (IOException e) {
						e.printStackTrace();
					}
		    		 BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		    		 String line;
		    		 try {
						while ((line = reader.readLine()) != null) {
							  if (line.contains("chrome.exe") || line.contains("firefox.exe") || line.contains("iexplore.exe") || line.contains("Safari.exe") || line.contains("opera.exe")) {
								  synchronized(lock_detections){
									  browserUsed = true;
								  }
							  }
						 }
					} catch (IOException e) {
						e.printStackTrace();
					}
		    		 
		    		 
		    		 //find prohibited websites
		    		 
		    		 
		  
					try {
						p = Runtime.getRuntime().exec("tasklist /v");
					} catch (IOException e) {
						e.printStackTrace();
					}
		    		 reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
		    		 try {
						while ((line = reader.readLine()) != null) {
							//if(line.contains("chrome"))System.out.println("-->"+line);
							boolean ok = true;
							for(String element: llista)
							{
								if(element == null || element.length()<4) continue;
								//System.out.println(element);
								if(line.toLowerCase().contains(element.toLowerCase()))
								{
									ok = false;
									break;
								}
							}
							if (!ok) {
								synchronized(lock_detections){
									prohibitedWebsitesVisited = true;
								}
							}
						}
					} catch (IOException e) {
						e.printStackTrace();
					}
		    		 
		    	}
		}
	}
	
	
	public class MonitorActivityThread extends Listener implements Runnable {

		
		int x = 0, y = 0;
		private Object lock_mouse = new Object();
		
		ExpirationList eList = new ExpirationList();
		private Object lock_list = new Object();
		
		public ArrayList<Expiration> getNonExpiredList(){
			synchronized(lock_list){
				return eList.getList();
			}
		}
		
	    public void run() {
	    	while(true){
	    		try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
	    		synchronized(lock_mouse) {
	    			x = MouseInfo.getPointerInfo().getLocation().x;
    				y = MouseInfo.getPointerInfo().getLocation().y;
    				synchronized(lock_list){
    					eList.addItem(new ActivityData(new java.awt.Point(x, y)), 60);
    				}
	    		}

	    	}
	    }
	    
	    public synchronized int getMouseX(){
	    	synchronized(lock_mouse) {
	    		return x;
	    	}
	    }
	    
	    public synchronized int getMouseY(){
	    	synchronized(lock_mouse) {
	    		return y;
	    	}
	    }
	    
	    public synchronized int calculateDistance(int foreignX, int foreignY){
	    	int newX, newY;
	    	synchronized(lock_mouse) {
	    		newX = Math.abs(foreignX-x);
	    		newY = Math.abs(foreignY-y);
	    	}
	    	return (int)(Math.sqrt(Math.pow(newX, 2) + Math.pow(newY, 2)));
	    }
	} 	
}
