package source;


import java.awt.Point;
import java.awt.MouseInfo;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JOptionPane;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;

import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfRect;
import org.opencv.core.Rect;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.highgui.VideoCapture;
import org.opencv.imgproc.Imgproc;
import org.opencv.objdetect.CascadeClassifier;

import Data.ActivityData;
import Data.Expiration;
import Data.ExpirationList;
import Data.RawPattern;
import Data.WebcamData;
import GUI.GUI;
import Interfaces.SecureStop;
import SocketWithServer.ClientSocket;

import source.Monitors.MonitorActivityThread;
import source.Monitors.MonitorWebcamThread;
import source.Monitors.MonitorWebsThread;


public class MonitorsManager {

	private Main main;
	private GUI gui;
	private Monitors monitors;
	
	private ScheduledAlarmThread sat;
	private ActivityDetectionThread adt;
	private DetectWebsitesThread dwt;
	private DetectFacesThread dft;
	private NotificationsThread nt;
	
	private boolean webcamNeverStarted = true;
	
	private int alarmTime=0, notificationsTime = 0, sensibility = 0;  
	private boolean pause = false;

	private Expiration predictionLockedByExpirationTime = null;
	private int lastNotificationSensibility = -1;
	
	
	public MonitorsManager(Main main){
		this.main = main;
		sat = new ScheduledAlarmThread();
		adt = new ActivityDetectionThread();
		dwt = new DetectWebsitesThread();
		dft = new DetectFacesThread();
		nt = new NotificationsThread();
	}
	

	public void setNotificationsTime(int time){
		notificationsTime = time;
	}
	
	public void setSensibility(int sensibility){
		monitors.setSensibility(sensibility);
	}
	
	public void setAlarmTime(int temps){
		alarmTime = temps;
	}
	
	public void setGUI(GUI gui){
		this.gui = gui;
		monitors = new Monitors();
	}

	public void setUpdatedList(){
		monitors.setUpdatedList();
	}
	
	public void setPause(boolean pause){
		this.pause = pause;
	}
	
	public DetectFacesThread getDetectFacesThreadInstance(){
		return dft;
	}
	
	public DetectWebsitesThread getDetectWebsitesThreadInstance(){
		return dwt;
	}
	
	public ActivityDetectionThread getActivityDetectionThreadInstance(){
		return adt;
	}
	
	public ScheduledAlarmThread getScheduledAlarmThreadInstance(){
		return sat;
	}
	
	public NotificationsThread getNotificationsThreadInstance(){
		return nt;
	}
	
	public class NotificationsThread implements Runnable, SecureStop {
		SocketWithServer.ClientSocket cs;
		boolean keepAlive = true;
		MonitorActivityThread mat;
		MonitorWebcamThread mwt;
		boolean alarmActivated = false;
		Object lock_alarmActivated = new Object();
		
		public RawPattern getLastPattern(){
			RawPattern rp = new RawPattern();
			
			//** Activity data **//
			Point lastP = null;
			int distTotal = 0;
			int count = 0;
			for(Expiration e: mat.getNonExpiredList()){
				ActivityData ad = (ActivityData) e;
				Point p = ad.getMouse();
				if(lastP == null)
					lastP = new Point((int)p.getX(), (int)p.getY());
				else{
					distTotal += lastP.distanceSq(p);
					lastP.move((int)p.getX(), (int)p.getY());
					count++;
				}
			}
			if(count > 0)
				distTotal /= count;
			rp.setAverageActivityLevel(distTotal);
			///////////////////////
			
			//** Webcam data **//
			lastP = null;
			int lastFS = 0;
			count = 0;
			int distTotalPos = 0;
			int distTotalDistanciaPantalla = 0;
			
			for(Expiration e : mwt.getNonExpiredList()){
				WebcamData wd = (WebcamData) e;
				Point p = wd.getFacePosition();
				int FS = wd.getFaceSize();
				if(lastP == null){
					lastP = new Point((int)p.getX(), (int)p.getY());
					lastFS = wd.getFaceSize();
				}
				else{
					distTotalPos += lastP.distanceSq(p);
					distTotalDistanciaPantalla += Math.abs(lastFS - FS);
					lastFS = FS;
					lastP.move((int)p.getX(), (int)p.getY());
					count++;
				}
			}
			if(count > 0){
				distTotalPos /= count;
				distTotalDistanciaPantalla /= count;
			}
			rp.setAverageFaceMovement(distTotalPos);
			rp.setAverageDistanceFromScreen(distTotalDistanciaPantalla);
			///////////////////////
			
			
			//**Other monitoring data**//
			rp.setAppExecutionTime(monitors.getSoftwareExecutionTime());
			rp.setDayTime(monitors.getHourOfDay());
			rp.setDayOfTheWeek(monitors.getDayOfWeek());
			/////////////////////////////
			return rp;
		}
		
		public void setAlarmActivated(){
			synchronized(lock_alarmActivated){
				alarmActivated = true;
				System.out.println("setAlarmActivated called");
			}
		}
		
		@Override
		public void run() {
			cs = new ClientSocket();
			Thread thread = new Thread(cs);
			thread.start();
			mat = monitors.listenActivityMonitor();
			mwt = monitors.listenWebcamMonitor(null, webcamNeverStarted);
			webcamNeverStarted = false;
			
			do{
				try {
					int patternReq = cs.getPatternRequestedByServer();
					RawPattern lastPattern = null;
					if(cs.isNotificationActivated()){
						lastNotificationSensibility = -1; //restart time before requesting prediction
						new Notification();
					}
					synchronized(lock_alarmActivated){
						if(alarmActivated){
							if(patternReq == Globals.positive){
								RawPattern rp = getLastPattern();
								System.out.println("prepare to send pattern positive");
								rp.setEndedWithDistraction(Globals.positive);
								cs.sendPattern(rp);
							}
						}	
						else if(patternReq == Globals.negative){
							lastPattern = getLastPattern();
							System.out.println(lastPattern.toString());
						}
					}
					if(lastPattern != null){	//we wait to check that this pattern is actually negative
						thread.sleep(10000);
						synchronized(lock_alarmActivated){
							if(!alarmActivated){
								lastPattern.setEndedWithDistraction(Globals.negative);
								cs.sendPattern(lastPattern);
								thread.sleep(60000);
							}
						}
					}
					
					thread.sleep(1000);
					int notificationSensibility = gui.getNotificationsSensibilityTime();
					if(lastNotificationSensibility != notificationSensibility){ //if notification's sensibility has changed...
						lastNotificationSensibility = notificationSensibility;
						predictionLockedByExpirationTime = new Expiration(notificationSensibility);
					}
					else if(predictionLockedByExpirationTime.isExpired()){
						System.out.println("before calling cs.predict(getLastPattern());");
						cs.predict(getLastPattern());
					}
					
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}while(keepAlive);
		}

		@Override
		public void SecureStop() {
			System.out.println("notifer secure stop");
			cs.setKeepWorking(false);
			keepAlive = false;
			monitors.ignoreActivityMonitor();
		}
		
	
	}
	
	public class DetectFacesThread implements Runnable, SecureStop {
		MonitorWebcamThread mwct;
		
		
		@Override
		public void run() {
			mwct = monitors.listenWebcamMonitor(this, webcamNeverStarted);
			webcamNeverStarted = false;
			    
		}
		

		public void startingWebcam(){
			gui.setWaitAMoment();
			gui.setEyesImageEnabled(false);
		}
		
		public void stopingWebcam(){
			gui.setDesUlls();
			gui.setEyesImageEnabled(true);
		}
		
		public void setEyesFoundImage(boolean found){
			gui.setEyesFoundImage(found);
		}
		
		public void communicateWithoutFace(int times){
			System.out.println("commmunicationwithoutface "+times);
			if (times > 20)
				soundAlarm();
		}
		
		@Override
		public void SecureStop() {
			if(mwct != null)
				monitors.ignoreWebcamMonitor(this);
						
		}
		
		
		
	}
	
	
	public class DetectWebsitesThread implements Runnable, SecureStop {
		MonitorWebsThread mwt;
		
		
	    public void run() {
	    	 mwt = monitors.listenWebsMonitor();
	    	 
	    	while(true){
	    		do{
	    			try {
						Thread.sleep(2000);
					} catch (InterruptedException e1) {
						e1.printStackTrace();
					}
    			}while(pause);	//wait while the user is modifying the list of prohibited websites
	    		
	    		if(!gui.getRadioEspecifiques().isSelected())	//detect browser
	    		{
	    			if(mwt.getBrowserUsed()) 
	    				soundAlarm();
		    		
	    		}
	    		else		//detect prohibited websites
	    		{
	    			if(mwt.getProhibitedWebsitesVisited())
	    				soundAlarm();
	    			
	    		}
	    	}
	    }


		@Override
		public void SecureStop() {
			if(mwt != null)
				monitors.ignoreActivityMonitor();
		}
	}
	
	public class ActivityDetectionThread implements Runnable, SecureStop {
		public int x=0, y=0;
		int segons;
		MonitorActivityThread mat;
		
		
	    public void run() { 
	    	segons=0; 
	        mat = monitors.listenActivityMonitor();
	        
	    	while(true){
		    	try {
					Thread.sleep(1100);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
		    	JTextField txtActivity = gui.getTextActivity();
		    	if(!txtActivity.getText().equals("") && alarmTime != Integer.parseInt(txtActivity.getText()))
		    	{
		    		try {
						Thread.sleep(4000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
		    		alarmTime = Integer.parseInt(txtActivity.getText());
		    	}
	    		if(mat.calculateDistance(x, y) > 0){
	    			x = mat.getMouseX();
	    			y = mat.getMouseY();
	    			segons=0;  
	    		}else segons++;  
	    		if(segons>alarmTime){
	    			 soundAlarm();
	    		}
	    	}
	    	 
	    }

		@Override
		public void SecureStop() {
			// TODO Auto-generated method stub
			if(mat != null)
				monitors.ignoreActivityMonitor();
		}   
		
	}
	
	
	public class ScheduledAlarmThread implements Runnable {
	    public void run() {
	    	while(true){
	    		try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
	    		
	    		
	    		Date date = new Date();
	    		
	    		SpinnerDateModel monthModel = new SpinnerDateModel(date, null, null, Calendar.HOUR_OF_DAY);
	    		JSpinner spinner = new JSpinner(monthModel);
	    		
	    		
	    		JSpinner .DateEditor de = new JSpinner.DateEditor(spinner, "HH:mm");
	    		spinner.setEditor(de);
	    		SpinnerDateModel modelModificat = gui.getModelModificat();
	    		if(modelModificat != null){
	    			SpinnerDateModel mm = (SpinnerDateModel) spinner.getModel();
	    			
	    			if(modelModificat.getDate().getHours() == mm.getDate().getHours()
	    					&& modelModificat.getDate().getMinutes() == mm.getDate().getMinutes()){
	    				Clip clip;   
						try { 
							clip = AudioSystem.getClip();

							InputStream audioSrc = getClass().getResourceAsStream(Globals.clock_sound);
							InputStream bufferedIn = new BufferedInputStream(audioSrc);
							AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);

		    		        clip.open(audioStream);  
		    		        clip.start();     
		    		         
		    		       break;
						} catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
							// TODO Auto-generated catch block
							//JOptionPane.showMessageDialog(null, "My Goodness, this is so concise");
							e.printStackTrace();
						}
	    			}
	    		}

	    	}
	    }
	    

	}
	
	public void soundAlarm(){
		System.out.println("sound alarm!");
		NotificationsThread nt = getNotificationsThreadInstance();
		if(nt != null){
			nt.setAlarmActivated();
		}
		Clip clip;   
		try { 
			clip = AudioSystem.getClip();
				
			
			InputStream audioSrc = getClass().getResourceAsStream(Globals.alarm_sound);
			InputStream bufferedIn = new BufferedInputStream(audioSrc);
			AudioInputStream audioStream = AudioSystem.getAudioInputStream(bufferedIn);

	        clip.open(audioStream);  
	        clip.start();     
	        try {
				Thread.sleep(30000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		} catch (LineUnavailableException | UnsupportedAudioFileException | IOException e) {
			// TODO Auto-generated catch block
			//JOptionPane.showMessageDialog(null, "My Goodness, this is so concise");
			JOptionPane.showMessageDialog(null,e.getMessage());
		}
	}
	

	

}
