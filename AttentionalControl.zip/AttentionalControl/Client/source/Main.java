package source;


import GUI.GUI;
import SocketWithServer.ClientSocket;


public class Main {
	private GUI gui;
	private MonitorsManager monitoring;
	
	 
	public Main(){ 
		
		monitoring = new MonitorsManager(this);
		gui = new GUI(this, monitoring); 
		monitoring.setGUI(gui); 
		gui.show();    
	} 
	 
	
	
	 
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Main m = new Main();
	}

}
