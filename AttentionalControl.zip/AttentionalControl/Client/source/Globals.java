package source;




public class Globals {
	public static String app_icon = "/Resources/ic_launcher.png";
	public static String haarcascade_eye = "Client/Resources/haarcascade_eye_tree_eyeglasses.xml";
	public static String haarcascade_face = "Client/Resources/haarcascade_frontalface_alt.xml";
	public static String eyes_icon = "Client/Resources/ulls.jpg";
	public static String noeyes_icon = "Client/Resources/noulls.jpg";
	public static String waves_sound = "/Resources/ones.wav";
	public static String clock_sound = "/Resources/despertador.wav";
	public static String alarm_sound = "/Resources/alarma.wav";
	public static String list_txt = "Client/llista.txt";
	public static String logs_txt = "Client/Logs.txt";
	
	//Server stuff
	public static int Server_Port = 60010;
	public static String Server_Host = "192.168.1.25";
	public static int request_prediction = 1;
	public static int request_what_training_patterns_do_you_need = 2;
	public static int request_i_send_new_training_pattern = 3;
	public static int positive = 1;
	public static int negative = 2;
	public static int nothing_to_do = 4;
	public static double maxAppAllowedCPUUsage = 0.3f; //30%, in this case
	public static int numOfNNInGeneration = 10;
	public static int numOfBestNN = 5; //This number must always be odd
	public static int numOfReproducibleNN = 6;
	
	
	
	public static int timeToTrain = 15; //seconds to train
	public static int standarize = 1;
	public static int normalize = 2;
	
	
}
